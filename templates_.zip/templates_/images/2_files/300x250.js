(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Warstwa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgUAyQgKgDgHgIQgHgHgDgKQgEgKAAgMQAAgKAEgKQAEgKAHgIQAHgHAJgEQAKgEALAAQANAAAKAFQAKAFAGAIQAGAJADALQADALgBALIhKAAQABAOAGAGQAHAGALAAQAIAAAHgEQAGgEABgFIAZAAQgGASgMAIQgNAIgRAAQgLAAgKgEgAAXgKQgCgLgGgFQgFgGgKAAQgGAAgEACQgFADgCADQgDADgBAEIgCAHIAuAAIAAAAg");
	this.shape.setTransform(-7.6464,-11.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AggA1IAAhnIAbAAIAAAUQACgFADgEIAHgHIAJgFQAFgBAGAAIAGABIAAAaIgFgBIgFAAQgIAAgFADQgGACgDAFQgCAFgCAFQgBAGAAAHIAAAug");
	this.shape_1.setTransform(-16.475,-11.65);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgdAyQgHgDgEgGQgEgFgCgIQgBgIgBgKIAAg+IAdAAIAAA5QAAANAEAHQAEAGAKAAQALAAAEgHQAGgHAAgQIAAg1IAdAAIAABmIgbAAIAAgOIgBAAQgGAJgJAEQgHAEgJAAQgLAAgIgDg");
	this.shape_2.setTransform(-26.55,-11.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AARBEIgNgBQgFgBgEgDQgFgCgCgFQgDgFAAgIIAAg8IgRAAIAAgTIARAAIAAgfIAcAAIAAAfIAUAAIAAATIgUAAIAAAzQAAAHACACQACADAIAAIAEgBIAEAAIAAAWIgIABIgIAAg");
	this.shape_3.setTransform(-35.825,-13.025);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgcA1QgGgCgFgEQgFgEgDgGQgCgFAAgIQAAgJADgGQADgGAFgDIALgEIANgDIAMgBIAKgCQAFgBADgDQADgCgBgEQAAgFgBgDIgEgEIgGgCIgHAAQgHAAgFADQgFAEgBAIIgcAAQAAgKAFgGQAEgHAHgEQAHgEAIgCIAQgBIAQABQAIABAHADQAGADAFAGQAEAGAAAJIAAA1IABANQAAAHACADIgcAAIgCgFIAAgFQgHAHgJADQgJACgJAAQgIAAgGgBgAAOAEIgGABIgGABIgGABIgGACIgGACIgEAFIgBAGIABAHIAEAEIAGACIAGABQAIAAAEgDQAFgDACgEIADgIIAAgGIAAgLIgEADg");
	this.shape_4.setTransform(-44.775,-11.525);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgUAyQgKgDgHgIQgHgHgDgKQgEgKAAgMQAAgKAEgKQAEgKAHgIQAHgHAJgEQAKgEALAAQANAAAKAFQAKAFAGAIQAGAJADALQADALgBALIhKAAQABAOAGAGQAHAGALAAQAIAAAHgEQAGgEABgFIAZAAQgGASgMAIQgNAIgRAAQgLAAgKgEgAAXgKQgCgLgGgFQgFgGgKAAQgGAAgEACQgFADgCADQgDADgBAEIgCAHIAuAAIAAAAg");
	this.shape_5.setTransform(-55.8964,-11.525);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgxBHIAAiNIBjAAIAAAaIhEAAIAAAhIA7AAIAAAYIg7AAIAAA6g");
	this.shape_6.setTransform(-66.725,-13.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgVAzQgKgEgHgHQgHgHgEgKQgEgKAAgNQAAgLAEgKQAEgKAHgHQAHgIAKgDQAKgEALAAQAMAAAKAEQAKADAHAIQAHAHADAKQAFAKAAALQAAANgFAKQgDAKgHAHQgHAHgKAEQgKADgMAAQgLAAgKgDgAgLgdQgFADgCAEQgDAFgCAGIgBALIABAMQACAGADAFQACAFAFACQAFADAGAAQAHAAAFgDQAFgCADgFIAEgLIABgMIgBgLIgEgLQgDgEgFgDQgFgDgHAAQgGAAgFADg");
	this.shape_7.setTransform(-84.2,-11.525);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgUAyQgKgDgHgIQgHgHgDgKQgEgKAAgMQAAgKAEgKQAEgKAHgIQAHgHAJgEQAKgEALAAQANAAAKAFQAKAFAGAIQAGAJADALQADALgBALIhKAAQABAOAGAGQAHAGALAAQAIAAAHgEQAGgEABgFIAZAAQgGASgMAIQgNAIgRAAQgLAAgKgEgAAXgKQgCgLgGgFQgFgGgKAAQgGAAgEACQgFADgCADQgDADgBAEIgCAHIAuAAIAAAAg");
	this.shape_8.setTransform(-95.7464,-11.525);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AAyA1IAAg6IAAgKQAAgEgCgEQgCgDgDgCQgDgCgHAAQgGAAgEADQgDACgCAEQgCADgBAFIgBAKIAAA4IgbAAIAAg5IAAgJQgBgEgBgEQgCgEgDgCQgEgDgHAAIgFABQgDABgDACQgDADgDAFQgBAEAAAIIAAA7IgdAAIAAhnIAbAAIAAAOIABAAQAFgIAHgEQAJgEAKAAQAJAAAJAEQAHADAEAKQAEgHAIgFQAJgFAKAAQAIAAAIACQAGACAFAEQAFAEADAIQADAHAAAKIAABEg");
	this.shape_9.setTransform(-110.25,-11.65);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgNBHIAAhmIAbAAIAABmgAgNgvIAAgXIAbAAIAAAXg");
	this.shape_10.setTransform(-121.575,-13.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgRBHIgviNIAhAAIAfBjIAAAAIAghjIAhAAIgwCNg");
	this.shape_11.setTransform(-130.15,-13.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AAlBHIgLgfIg0AAIgLAfIggAAIA2iNIAfAAIA2CNgAASAQIgSgzIAAAAIgSAzIAkAAg");
	this.shape_12.setTransform(-148.225,-13.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol8, new cjs.Rectangle(-157.1,-27.8,157.1,27.8), null);


(lib.Symbol7 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Warstwa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgeAfIAAg9IA9AAIAAA9g");
	this.shape.setTransform(11.725,-13.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAkBmIgkiIIAAAAIgjCIIg6AAIhAjLIA7AAIAlCKIABAAIAiiKIA2AAIAiCJIABAAIAmiJIA5AAIhADLg");
	this.shape_1.setTransform(-9.425,-20.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgoBkQgTgIgOgOQgNgOgIgUQgHgUAAgYQAAgWAIgTQAHgUAOgOQAOgPATgIQATgIAWAAQAbAAATAKQATAKANARQAMARAGAVQAFAWgBAXIiTAAQABAbANAMQANANAWAAQARAAANgJQAMgIADgKIAxAAQgMAlgYAQQgZAPgjAAQgXAAgTgHgAAtgVQgDgVgLgLQgKgLgUAAQgNAAgIAEQgJAFgGAHQgFAGgCAIIgDANIBaAAIAAAAg");
	this.shape_2.setTransform(-36.4089,-20.775);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgbCNIAAjLIA3AAIAADLgAgbheIAAguIA3AAIAAAug");
	this.shape_3.setTransform(-52.45,-24.65);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgeBmIhGjLIA7AAIAqCKIABAAIAriKIA4AAIhGDLg");
	this.shape_4.setTransform(-67.425,-20.775);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgoBkQgTgIgOgOQgNgOgIgUQgHgUAAgYQAAgWAIgTQAHgUAOgOQAOgPATgIQATgIAWAAQAbAAATAKQATAKANARQAMARAGAVQAFAWgBAXIiTAAQABAbANAMQANANAWAAQARAAANgJQAMgIADgKIAxAAQgMAlgYAQQgZAPgjAAQgXAAgTgHgAAtgVQgDgVgLgLQgKgLgUAAQgNAAgIAEQgJAFgGAHQgFAGgCAIIgDANIBaAAIAAAAg");
	this.shape_5.setTransform(-88.6089,-20.775);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AA7CNQgFgNgBgTIgDgjQgDgXgKgKQgLgLgYAAIg8AAIAABvIg/AAIAAkZICYAAQATAAAPAGQAPAGALALQALALAGANQAFAOAAARQAAAYgKATQgLASgYAIIAAABQAMAEAIAGQAHAHAFAIQAFAJACALIADAWIAAAPIACATIADASQACAIAEAGgAg6gNIBDAAQAVAAAKgJQALgJAAgWQAAgUgLgKQgKgJgVAAIhDAAg");
	this.shape_6.setTransform(-113.2,-24.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol7, new cjs.Rectangle(-130,-51,149,51), null);


(lib.Symbol6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Warstwa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgrBkQgTgIgOgOQgOgOgHgTQgHgUgBgZQABgXAHgUQAHgUAOgOQAOgOATgIQAUgHAXAAQAYAAAUAHQATAIAOAOQAOAOAHAUQAIAUAAAXQAAAZgIAUQgHATgOAOQgOAOgTAIQgUAHgYAAQgXAAgUgHgAgXg6QgJAFgGAJQgFAKgDALQgDAMAAALQAAANADALQADAMAFAJQAGAKAJAFQAKAGANAAQAOAAAKgGQAJgFAGgKQAGgJACgMQACgLAAgNQAAgLgCgMQgCgLgGgKQgGgJgJgFQgKgGgOAAQgNAAgKAGg");
	this.shape.setTransform(-163.05,-20.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgoBkQgTgIgOgOQgNgOgIgUQgHgUAAgYQAAgWAIgTQAHgUAOgOQAOgPATgIQATgIAWAAQAbAAATAKQATAKANARQAMARAGAVQAFAWgBAXIiTAAQABAbANAMQANANAWAAQARAAANgJQAMgIADgKIAxAAQgMAlgYAQQgZAPgjAAQgXAAgTgHgAAtgVQgDgVgLgLQgKgLgUAAQgNAAgIAEQgJAFgGAHQgFAGgCAIIgDANIBaAAIAAAAg");
	this.shape_1.setTransform(-186.0089,-20.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("Ag0CHQgRgJgLgPQgMgPgFgUQgGgUAAgWQAAgUAGgSQAFgTAMgPQALgOARgKQARgIAWAAQASAAAQAHQAQAJAKAPIABAAIAAhoIA4AAIAAEaIg2AAIAAgaIAAAAQgKAQgQAIQgQAGgTAAQgXABgSgJgAgVgWQgJAFgGAJQgFAJgDALQgCALAAANQAAAMACAMQADAMAGAJQAGAKAKAFQAIAGAMAAQAOAAAKgGQAJgFAFgKQAGgJACgMQADgMAAgMQAAgNgDgLQgCgMgGgIQgGgJgIgFQgKgGgOAAQgMAAgKAGg");
	this.shape_2.setTransform(-209.4,-24.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgbCNIAAjLIA3AAIAADLgAgbheIAAguIA3AAIAAAug");
	this.shape_3.setTransform(-225.75,-24.65);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgjCNIhbkZIA/AAIA/DFIAAAAIA/jFIBAAAIhdEZg");
	this.shape_4.setTransform(-242.875,-24.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol6, new cjs.Rectangle(-257.3,-51,108.10000000000002,51), null);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Warstwa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(-150,-125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-300,-250,300,250);


(lib.Symbol2 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Warstwa_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgKAyQgFgBgEgCQgFgDgCgEQgDgEAAgGIAMAAQAAADACADIAEADIAGACIAFABQAGAAAEgCQAEgCADgEQADgDABgFIABgLIAAgFQgDAHgHADQgGADgGAAQgIAAgGgDQgGgDgEgFQgEgFgCgHQgCgFAAgIQAAgGACgHQABgHAEgFQAEgGAGgDQAHgEAIAAQAHAAAGADQAGADADAGIAAgKIALAAIAABBQAAASgIAJQgIAJgRAAIgKgCgAgIgmQgEACgDAEQgCADgBAFQgCAFAAAFIABAKQABAEADAEQACAEAEACQAEADAFAAQAGAAAEgDQAEgCADgEQACgEABgEIABgKIgBgKQgBgEgCgEQgDgEgEgCQgEgCgFAAQgFAAgEACg");
	this.shape.setTransform(-24.575,-13.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AASAlIAAgwQAAgGgEgEQgEgFgHAAQgEABgEABIgHAFIgEAHIgBAJIAAAoIgMAAIAAhIIALAAIAAAMIAAAAQAIgNAPAAQAHAAAFACQAFACADAEQACADABAFQACAEAAAHIAAAug");
	this.shape_1.setTransform(-31.9,-15.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgFAyIAAhIIALAAIAABIgAgFgiIAAgPIALAAIAAAPg");
	this.shape_2.setTransform(-36.95,-16.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgEAyIgGgCIgGgDIgFgFIAAAJIgMAAIAAhjIAMAAIAAAmQADgGAGgDQAGgDAHAAQAIAAAHADQAGADAEAGQAEAFACAHQACAGAAAHQAAAIgCAHQgCAHgEAFQgEAFgGADQgHADgIAAIgFgBgAgKgLQgEACgDAEQgDAEgBAEIgBAKIABAKIAEAJIAHAGQAFACAFAAQAGAAAEgCQAEgCADgEIAEgJIABgLQAAgFgCgEIgEgIIgHgGQgEgCgFAAQgGAAgEACg");
	this.shape_3.setTransform(-42.025,-16.475);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AASAjQgCgCAAgGQgGAGgGACQgGADgHAAIgJgBQgFgBgDgDQgDgCgCgEQgCgEAAgFQAAgGACgEQACgEAEgDIAIgDIAJgCIAIgBIAIgBQADgBACgCQACgCAAgDQAAgEgCgDIgDgDIgGgCIgEAAQgIAAgFADQgFACAAAIIgMAAQAAgGADgFQACgFAEgCQAFgDAFgCIALgBIAJABIAJADQAEACACAEQACAEABAGIAAAkIAAAGQAAABAAAAQABABAAAAQABAAAAAAQABAAAAAAIAEAAIAAAJQgDACgFAAQgFAAgDgDgAAJABIgIACIgHABIgHACQgDABgCADQgCACgBAFQAAADACACIADADIAEACIAFAAQAGAAADgBQAFgCADgCIADgGIABgFIAAgLQgBABgEAAg");
	this.shape_4.setTransform(-49.65,-15.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgFAyIAAhjIALAAIAABjg");
	this.shape_5.setTransform(-54.7,-16.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgFAyIAAhjIALAAIAABjg");
	this.shape_6.setTransform(-57.4,-16.55);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgOAjQgHgDgEgFQgFgFgCgHQgCgHAAgIQAAgHACgHQACgHAFgFQAEgFAHgDQAGgDAIAAQAJAAAGADQAHADAEAFQAFAFACAHQACAHAAAHQAAAIgCAHQgCAHgFAFQgEAFgHADQgGADgJAAQgIAAgGgDgAgIgYQgEABgDAEQgDADgCAFQgCAGAAAFQAAAHACAFQACAFADADQADAEAEACQAEABAEAAQAFAAAEgBQAEgCADgEQADgDACgFQACgFAAgHQAAgFgCgGQgCgFgDgDQgDgEgEgBQgEgCgFAAQgEAAgEACg");
	this.shape_7.setTransform(-62.575,-15.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgNAjQgGgDgFgEQgDgFgDgHQgCgHAAgIQAAgHACgHQACgHAEgGQAFgFAGgDQAGgDAIAAQAHAAAEACQAGABAEADQAEADADAFQACAFABAGIgMAAQgCgHgEgEQgEgDgIAAQgFAAgEACQgFACgDAEIgDAJIgBAKQAAAFABAFQABAFACADQADAEAEACQAEACAFAAQAJAAAEgEQAGgFAAgIIANAAQgCANgIAIQgIAHgOAAQgHAAgHgDg");
	this.shape_8.setTransform(-69.9,-15.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAKAvIgIgBQgCAAgCgCQgCgBgBgEIgBgIIAAgtIgMAAIAAgLIAMAAIAAgVIALAAIAAAVIAOAAIAAALIgOAAIAAAsIAAAEIABACIADAAIAFAAIAFAAIAAALg");
	this.shape_9.setTransform(-79.125,-16.25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgSAlIAAhHIAMAAIAAAPQAEgJAFgEQAHgEAJAAIAAANQgHAAgFACQgFACgCAEQgDADgCAGQgBAFAAAGIAAAgg");
	this.shape_10.setTransform(-82.7,-15.2525);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AASAjQgCgCAAgGQgGAGgGACQgGADgHAAIgJgBQgFgBgDgDQgDgCgCgEQgCgEAAgFQAAgGACgEQACgEADgDIAJgDIAJgCIAIgBIAIgBQADgBACgCQACgCAAgDQAAgEgCgDIgEgDIgFgCIgEAAQgIAAgFADQgFACAAAIIgMAAQAAgGADgFQACgFAFgCQAEgDAFgCIALgBIAJABIAJADQAEACACAEQACAEABAGIAAAkIAAAGQAAABAAAAQABABAAAAQABAAAAAAQABAAAAAAIAEAAIAAAJQgDACgFAAQgFAAgDgDgAAJABIgIACIgHABIgHACQgDABgCADQgCACAAAFQAAADABACIADADIAFACIAEAAQAHAAACgBQAFgCACgCIAEgGIACgFIAAgLQgDABgDAAg");
	this.shape_11.setTransform(-88.7,-15.175);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAKAvIgIgBQgCAAgCgCQgCgBgBgEIgBgIIAAgtIgMAAIAAgLIAMAAIAAgVIALAAIAAAVIAOAAIAAALIgOAAIAAAsIAAAEIABACIADAAIAFAAIAFAAIAAALg");
	this.shape_12.setTransform(-94.525,-16.25);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgOAyQgHgCgGgEQgFgFgEgGQgDgHAAgJIANAAQAAAGACAFQACAFAEADQAEACAGACIAKABIAJgBIAIgCQADgCADgEQACgEAAgFQAAgFgDgEQgCgCgFgCIgKgEIgLgDIgMgCIgKgFQgFgCgCgFQgDgEAAgHQAAgHADgGQADgFAFgEQAFgEAHgCQAGgBAHAAQAHAAAHABQAGACAFAFQAFADADAGQADAGAAAIIgMAAQgCgKgGgFQgHgFgJAAIgIAAIgIADQgDADgCADQgCADAAAFQAAAFADADQADADAEABIALADIAKADIAMADIAKAEQAFAEADAFQACAEAAAHQAAAJgDAGQgEAFgFAEQgGADgHABQgHACgHAAQgHAAgIgCg");
	this.shape_13.setTransform(-100.725,-16.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(3));

	// Warstwa_1
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("Ao5CoQg8AAAAg9IAAjWQAAg7A8AAIRzAAQA8AAAAA7IAADWQAAA9g8AAg");
	this.shape_14.setTransform(-63,-16.75);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(0,0,0,0.698)").s().p("Ao5CoQg8AAAAg9IAAjWQAAg7A8AAIRzAAQA8AAAAA7IAADWQAAA9g8AAg");
	this.shape_15.setTransform(-63,-16.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14}]}).to({state:[{t:this.shape_15}]},1).wait(2));

	// Warstwa_2
	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#9ECF91").s().p("A4ZV/Qg9AAABg8MAAAgqFQgBg8A9AAMAw0AAAQA7AAAAA8MAAAAqFQAAA8g7AAg");
	this.shape_16.setTransform(-131.25,-107.675);

	this.timeline.addTween(cjs.Tween.get(this.shape_16).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-293.5,-248.4,324.5,281.5);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Warstwa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("ADmAyIgGgJIgIAFQglAVgnAAQgdAAgMgTIgCgCIgBAAQgYAUgXAAQgXAAABgZQAAgLAEgQQAEgOAAgJQABgNgJAAQgJAAgNAWQgMAVgBAVQgBAQADAHQgYABgKgJQgJgHABgSQAAgMADgKQADgKABgJQAAgNgKAAQgJAAgKAUQgKASgCAWQAAAUADAHQgYABgLgLQgEgFgCgIIgEAEQgYAUgYAAQgLAAgGgHQgFgHAAgLQAAgLAHgYIAHgZQAAgJgGAAQgCAAgJAGQgHAUgXAcQggApgWAAQgOAAgKgZIgMgtQgHgZgIAAQgCAAgLAHIgHgJIAXgUQAPgOAIAAQATgCAEAaIAGAkQAGAXAGAAQAFAAAKgQQAKgOABgIQABgNgMAAQgGAAgGACQAMglAhABQAVAAACAZIAKgJQAQgOAHAAQAMgBAFAHQAGAIgCANQgFAWgFAfQAAAPALAAQAFAAANgLIAAAAIADgRQADgPAAgKQABgGgEAAQgCAAgKAHIgJgJIAXgUQAPgOAFAAQAJgBAGAIQAGAIAAALIgBAHQAFgIAHgGQARgOAUgCQARgBAIAJQAFAIgBAOIAGgEQAIgKAIgFQANgKAOgBQARgBAHAJQAHAIgBAOQAAAKgFASIgEAVQAAAHABADQACADAHAAQADAAAGgEIgBgJQABgbAZgaQAcgcAlAAQAjAAACAcQACASgWARQgWAVgjAFQAHAJAMAAQAaAAAegNIADgBIgBgEQgCgdAYgZQAagcAnAAQAYAAANAQQAMAPgBAYQgBAfgXAXQgXAYghAAQgdAAgOgSgAEQgRQgKAQgBAQQAAAJADAHQAEAHAHAAQAQAAAMgSQAJgQABgPQAAgKgDgIQgDgHgFAAQgTAAgLATgACTgSQgLAOgBANIAAAEQASgGANgMQAKgLAAgHQABgJgJAAQgKAAgLAOg");
	this.shape.setTransform(-35.3212,-6.7513);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AheAQQABghAnggQAnggAvAAQAbAAATAWQATAXgCAVQgBAgggAfQgkAigwAAQhLAAADhCg");
	this.shape_1.setTransform(-50.8,-17.4,0.2679,0.2635,0,0,0,-0.4,0.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70.6,-19.6,70.6,19.6);


// stage content:
(lib._300x250 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		if (!this.looped) this.looped = 1;
		
		
		this.clicktagbtn.addEventListener('click', gourl.bind(this));
		
		function gourl(){
			Enabler.exit("User exit");
		}
		this.clicktagbtn.addEventListener('click', gourl.bind(this));
		
		function gourl(){
			Enabler.exit("User exit");
		}
	}
	this.frame_449 = function() {
		if (this.looped++ > 1) this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(449).call(this.frame_449).wait(1));

	// Warstwa_11
	this.instance = new lib.Symbol3();
	this.instance.parent = this;
	this.instance.setTransform(150,125,1,1,0,0,0,-150,-125);
	new cjs.ButtonHelper(this.instance, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:0},7,cjs.Ease.get(1)).to({_off:true},1).wait(442));

	// Warstwa_10
	this.instance_1 = new lib.Symbol1("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(60.45,221.7,1.1899,1.1899,0,0,0,-35.3,-6.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("A3bzhMAu3AAAMAAAAnDMgu3AAAg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_1}]}).wait(450));

	// Warstwa_8
	this.instance_2 = new lib.Symbol6();
	this.instance_2.parent = this;
	this.instance_2.setTransform(125.65,38.3,1,1,0,0,0,-128.7,-25.6);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(320).to({_off:false},0).to({x:144.65,alpha:1},10,cjs.Ease.get(1)).wait(120));

	// Warstwa_7
	this.instance_3 = new lib.Symbol7();
	this.instance_3.parent = this;
	this.instance_3.setTransform(62.05,76.35,1,1,0,0,0,-65,-25.6);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(322).to({_off:false},0).to({x:81.05,alpha:1},10,cjs.Ease.get(1)).wait(118));

	// Warstwa_6
	this.instance_4 = new lib.Symbol8();
	this.instance_4.parent = this;
	this.instance_4.setTransform(75.6,114.4,1,1,0,0,0,-78.5,-14);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(343).to({_off:false},0).to({x:94.6,alpha:1},10,cjs.Ease.get(1)).wait(97));

	// Warstwa_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AghBTQgRgGgLgMQgLgMgGgRQgGgQAAgUQAAgSAGgQQAGgRAMgMQALgMAQgHQAQgHATAAQAWAAAQAIQAQAJAKAOQALAOAEASQAFASgBATIh6AAQABAXAKAKQALALATAAQAOAAAKgHQAKgIACgHIAqAAQgKAegVANQgUAOgdAAQgTAAgQgHgAAmgRQgDgSgJgJQgIgKgRAAQgLAAgHAEQgHAEgFAGQgEAFgCAGQgCAHAAAFIBLAAIAAAAg");
	this.shape_1.setTransform(277.7673,45.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgbBXQgOgDgLgHQgLgHgHgLQgHgLgBgSIAtAAQAAAHACAGQAEAFAFAEQAFADAGACQAGACAHAAIAKgBQAFgBAFgDIAHgGQADgFAAgGQAAgKgOgGQgOgFgYgFIgUgGQgKgDgHgEQgHgFgFgIQgFgHAAgMQAAgQAGgLQAHgLAKgFQALgHANgCQAOgDANAAQANAAANADQANACAKAHQALAGAGALQAHAKABAPIgsAAQgBgNgJgFQgJgEgMAAIgIAAIgJACIgGAFQgDADAAAGQAAAFAFAFQAFAEAGACIAQAFIAUAEQALACAJADQAJADAJAGQAHAEAEAJQAFAIAAAMQAAARgGALQgIALgKAHQgLAHgOADQgOADgOAAQgPAAgOgDg");
	this.shape_2.setTransform(259.85,45.35);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgWB2IAAiqIAtAAIAACqgAgWhOIAAgnIAtAAIAAAng");
	this.shape_3.setTransform(247.15,42.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("ABTBYIAAhgIAAgRQgBgHgDgFQgDgGgFgDQgHgEgJAAQgKAAgHAEQgFAEgEAGQgDAGgCAIIgBAPIAABfIguAAIAAhfIAAgPQAAgHgCgHQgDgGgGgEQgFgEgMAAIgIACQgGABgFAEQgFAFgEAIQgEAHAAANIAABiIgvAAIAAiqIAtAAIAAAXIAAAAQAKgNANgIQANgGAQgBQARABANAFQAMAHAIAQQAHgLANgJQANgJASAAQAOABALADQALADAJAHQAIAIAFALQAEAMAAAQIAAByg");
	this.shape_4.setTransform(228.35,45.15);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgjBTQgRgGgLgMQgMgLgGgRQgGgQAAgVQAAgTAGgRQAGgRAMgLQALgMARgGQAQgHATAAQAUAAAQAHQARAGALAMQAMALAGARQAGARAAATQAAAVgGAQQgGARgMALQgLAMgRAGQgQAHgUAAQgTAAgQgHgAgTgxQgIAFgFAIQgEAHgCAKQgCAKAAAJQAAAKACAKQACAKAEAIQAFAHAIAFQAIAFALAAQAMAAAIgFQAIgFAFgHQAEgIACgKQACgKAAgKQAAgJgCgKQgCgKgEgHQgFgIgIgFQgIgFgMAAQgLAAgIAFg");
	this.shape_5.setTransform(203.725,45.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("Ag2BYIAAiqIAtAAIAAAfIAAAAQADgHAGgHQAFgHAHgEQAHgGAIgCQAJgDAJAAIAKACIAAArIgIgBIgJAAQgNAAgJAEQgJAFgFAHQgEAHgDAKQgCAKAAAKIAABOg");
	this.shape_6.setTransform(188.475,45.15);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AhWB2IAAjmIAtAAIAAAWIAAAAQAJgOANgHQANgFAPgBQAUAAAPAIQAOAHAKANQAJANAFAQQAFARAAASQAAARgFAPQgFAQgJAMQgJAMgOAIQgOAHgTAAQgPAAgNgGQgOgHgIgMIgBAAIAABRgAgThMQgIAEgFAIQgFAHgCAKQgCALAAAJQAAALADAKQACAIAEAJQAFAGAIAFQAIAFALAAQALAAAIgFQAHgFAFgGQAFgJACgIQACgKAAgLQAAgJgCgLQgDgJgEgIQgFgIgIgEQgIgFgKgBQgMABgHAFg");
	this.shape_7.setTransform(171.925,48.15);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AAbBwQgLAAgJgCQgJgBgIgEQgHgFgEgIQgEgIAAgNIAAhjIgdAAIAAggIAdAAIAAgyIAtAAIAAAyIAjAAIAAAgIgjAAIAABTQAAAMAEAEQAEAEAMAAIAIgBIAHgBIAAAlIgNACIgPAAg");
	this.shape_8.setTransform(147.175,42.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgQA1IAAhpIAiAAIAABpg");
	this.shape_9.setTransform(137.35,35.65);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAhBYIAAhgQAAgVgGgKQgHgLgRAAQgSAAgJAMQgJALAAAaIAABZIguAAIAAiqIAsAAIAAAYIABAAQAJgPAPgHQANgHAOAAQAUABALAEQAMAFAIAKQAGAIADAOQADANAAAPIAABpg");
	this.shape_10.setTransform(123.35,45.15);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgvBXQgKgDgIgHQgIgGgFgJQgEgKAAgNQAAgPAFgJQAFgKAIgFQAIgFALgDIAVgEIAUgDIASgDQAHgCAFgDQAFgEgBgIQAAgHgCgFQgDgEgEgCQgEgDgFgBIgMgBQgNAAgIAGQgIAGgBAOIgvAAQABgQAHgLQAIgLALgHQALgGAOgDQAOgDANAAQANAAANACQAOACAKAFQALAFAHAKQAHAJAAAQIAABXQAAAMACAKQABALADAFIgvAAIgCgIIgCgIQgLALgPAFQgOAFgQAAQgMAAgLgDgAAXAGIgKACIgKACIgLACIgKACQgFACgEADQgEADgCAEQgCAEAAAHQAAAGACAEQACAFAEACQAEADAFABIALABQANAAAIgFQAHgFAEgGQAEgHABgGIAAgLIAAgRQgDACgEACg");
	this.shape_11.setTransform(104.375,45.375);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AggBTQgQgGgLgMQgMgLgGgQQgGgQAAgUQAAgSAGgRQAFgRAMgNQALgMAQgHQAQgHAUAAQAPAAAOAEQAOAEALAIQALAIAHAMQAHAMABARIguAAQgEgegeAAQgLAAgHAGQgIAFgFAIQgEAIgCAJQgCAKAAAJQAAAJACAKQACAJAEAIQAFAIAHAFQAIAFAKAAQAQAAAJgKQAKgJACgQIAtAAQgEAigWASQgWASgiAAQgSAAgQgHg");
	this.shape_12.setTransform(86.125,45.375);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AghBTQgRgGgLgMQgLgMgGgRQgGgQAAgUQAAgSAGgQQAGgRAMgMQALgMAQgHQAQgHATAAQAWAAAQAIQAQAJAKAOQALAOAEASQAFASgBATIh6AAQABAXAKAKQALALATAAQAOAAAKgHQAKgIACgHIAqAAQgKAegVANQgUAOgdAAQgTAAgQgHgAAmgRQgDgSgJgJQgIgKgRAAQgLAAgHAEQgHAEgFAGQgEAFgCAGQgCAHAAAFIBLAAIAAAAg");
	this.shape_13.setTransform(58.6173,45.375);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AAoB2IgoigIAAAAIgnCgIg0AAIg/jrIA0AAIAlCgIABAAIApigIAvAAIApChIAAAAIAnihIAzAAIhADrg");
	this.shape_14.setTransform(33.975,42.125);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgZAZIAAgxIAzAAIAAAxg");
	this.shape_15.setTransform(165.825,122.05);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AAbB2IguhMIgSARIAAA7IgvAAIAAjrIAvAAIAAB+IA7g9IA3AAIhAA+IBIBsg");
	this.shape_16.setTransform(153.35,112.825);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgRByQgPgGgHgOIgBAAIAAAVIgtAAIAAjqIAvAAIAABWIABAAQAIgOAPgFQAOgHAPAAQAOAAAMAGQANAFAJALQAKALAHAQQAGARAAAXQAAAXgGARQgHASgKALQgJAKgNAFQgMAGgOAAQgRAAgPgGgAgSgTQgHAFgFAHQgFAHgCAKQgDAJABALQgBALADAKQACAJAFAIQAFAIAHAFQAIAEAKAAQAKAAAHgEQAIgFAFgIQAFgIACgJQACgKABgLQgBgLgCgJQgCgKgFgHQgFgHgIgFQgHgEgKAAQgKAAgIAEg");
	this.shape_17.setTransform(96.2,113.05);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgrBwQgOgHgKgMQgJgOgFgQQgFgQAAgSQAAgSAFgPQAFgPAJgNQAKgMAOgHQAOgHATgBQAOABAOAGQANAGAIANIABAAIAAhWIAvAAIAADqIgtAAIAAgVIAAAAQgJAOgNAFQgNAHgQAAQgTAAgPgIgAgRgTQgIAFgFAIQgEAGgDAKQgCAKAAAKQAAAKADAKQACAKAFAHQAFAJAIAEQAIAFAKAAQALAAAIgFQAHgEAFgIQAFgIACgKQACgKAAgKQAAgLgCgJQgCgKgFgHQgFgHgHgFQgIgEgLAAQgLAAgIAEg");
	this.shape_18.setTransform(75.825,113.05);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgaB2IAAiKIgcAAIAAggIAcAAIAAgNQAAgXAOgOQAOgPAcAAIANABIAMAAIAAAjIgRgBQgKAAgEAFQgEAEAAALIAAAKIAhAAIAAAgIghAAIAACKg");
	this.shape_19.setTransform(23.9,112.825);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AghBTQgRgGgLgMQgLgMgGgRQgGgQAAgUQAAgSAGgQQAGgRAMgMQALgMAQgHQAQgHATAAQAWAAAQAIQAQAJAKAOQALAOAEASQAFASgBATIh6AAQABAXAKAKQALALATAAQAOAAAKgHQAKgIACgHIAqAAQgKAegVANQgUAOgdAAQgTAAgQgHgAAmgRQgDgSgJgJQgIgKgRAAQgLAAgHAEQgHAEgFAGQgEAFgCAGQgCAHAAAFIBLAAIAAAAg");
	this.shape_20.setTransform(200.7173,80.725);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgrBwQgOgHgKgNQgJgMgFgRQgFgRAAgRQAAgRAFgQQAFgQAJgMQAKgMAOgHQAOgIATAAQAOABAOAGQANAGAIANIABAAIAAhWIAvAAIAADrIgtAAIAAgXIAAAAQgJAOgNAGQgNAHgQAAQgTAAgPgIgAgRgSQgIAEgFAHQgEAHgDAKQgCAJAAALQAAAKADAKQACAKAFAHQAFAJAIAEQAIAFAKAAQALAAAIgFQAHgFAFgHQAFgIACgKQACgKAAgKQAAgLgCgJQgCgKgFgHQgFgHgHgEQgIgGgLAAQgLAAgIAGg");
	this.shape_21.setTransform(181.225,77.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgWB2IAAiqIAuAAIAACqgAgWhOIAAgnIAuAAIAAAng");
	this.shape_22.setTransform(167.65,77.475);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgZBVIg6ipIAxAAIAjBzIABAAIAkhzIAuAAIg6Cpg");
	this.shape_23.setTransform(155.225,80.725);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AghBTQgRgGgLgMQgLgMgGgRQgGgQAAgUQAAgSAGgQQAGgRAMgMQALgMAQgHQAQgHATAAQAWAAAQAIQAQAJAKAOQALAOAEASQAFASgBATIh6AAQABAXAKAKQALALATAAQAOAAAKgHQAKgIACgHIAqAAQgKAegVANQgUAOgdAAQgTAAgQgHgAAmgRQgDgSgJgJQgIgKgRAAQgLAAgHAEQgHAEgFAGQgEAFgCAGQgCAHAAAFIBLAAIAAAAg");
	this.shape_24.setTransform(128.8173,80.725);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgZBVIg6ipIAxAAIAjBzIABAAIAkhzIAuAAIg6Cpg");
	this.shape_25.setTransform(111.175,80.725);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgXB2IAAiqIAuAAIAACqgAgXhOIAAgnIAuAAIAAAng");
	this.shape_26.setTransform(98.75,77.475);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AAbBvQgLAAgJgBQgJgBgIgEQgHgFgEgIQgEgIAAgMIAAhkIgdAAIAAggIAdAAIAAgyIAtAAIAAAyIAjAAIAAAgIgjAAIAABTQAAAMAEAEQAEAEAMAAIAIgBIAHgBIAAAlIgNABIgPAAg");
	this.shape_27.setTransform(88.975,78.25);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgWB2IAAiqIAuAAIAACqgAgWhOIAAgnIAuAAIAAAng");
	this.shape_28.setTransform(79.45,77.475);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgbBXQgOgDgLgHQgLgHgHgLQgHgMgBgRIAsAAQAAAIAEAFQADAGAFADQAFAEAGABQAHACAFAAIALgBQAFgCAFgCIAHgHQADgEAAgGQAAgLgOgFQgOgFgYgGIgUgFQgKgDgHgEQgHgGgFgHQgFgIAAgLQAAgQAHgLQAGgKAKgHQALgGANgDQAOgCANAAQANAAANADQANADALAGQAJAGAIAKQAGALABAPIgsAAQgBgNgJgFQgKgEgLAAIgJAAIgIACIgHAFQgCADAAAFQAAAGAFAFQAEAEAIACIAQAFIATAEQAKACAKAEQAKADAHAFQAIAFAEAHQAFAJAAAMQAAAQgHAMQgGALgMAIQgKAGgOADQgOADgPAAQgNAAgPgDg");
	this.shape_29.setTransform(66.75,80.7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgjBTQgRgGgLgMQgMgLgGgRQgGgQAAgVQAAgTAGgRQAGgRAMgLQALgMARgGQAQgHATAAQAUAAAQAHQARAGALAMQAMALAGARQAGARAAATQAAAVgGAQQgGARgMALQgLAMgRAGQgQAHgUAAQgTAAgQgHgAgTgxQgIAFgFAIQgEAHgCAKQgCAKAAAJQAAAKACAKQACAKAEAIQAFAHAIAFQAIAFALAAQAMAAAIgFQAIgFAFgHQAEgIACgKQACgKAAgKQAAgJgCgKQgCgKgEgHQgFgIgIgFQgIgFgMAAQgLAAgIAFg");
	this.shape_30.setTransform(48.225,80.725);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AhWB1IAAjlIAtAAIAAAWIAAAAQAJgOANgGQANgHAPAAQAUAAAPAIQAOAHAKANQAJANAFAQQAFARAAASQAAARgFAPQgFAQgJAMQgJANgOAGQgOAIgTAAQgPAAgNgHQgOgGgIgNIgBAAIAABRgAgThMQgIAEgFAIQgFAHgCAKQgCAKAAAKQAAALADAKQACAJAEAHQAFAIAIAEQAIAFALAAQALAAAIgFQAHgEAFgIQAFgHACgJQACgKAAgLQAAgKgCgKQgDgJgEgIQgFgIgIgEQgIgGgKAAQgMAAgHAGg");
	this.shape_31.setTransform(28.875,83.5);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AghBTQgRgGgLgMQgLgMgGgRQgGgQAAgUQAAgSAGgQQAGgRAMgMQALgMAQgHQAQgHATAAQAWAAAQAIQAQAJAKAOQALAOAEASQAFASgBATIh6AAQABAXAKAKQALALATAAQAOAAAKgHQAKgIACgHIAqAAQgKAegVANQgUAOgdAAQgTAAgQgHgAAmgRQgDgSgJgJQgIgKgRAAQgLAAgHAEQgHAEgFAGQgEAFgCAGQgCAHAAAFIBLAAIAAAAg");
	this.shape_32.setTransform(277.7673,45.375);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgjBTQgRgGgLgMQgMgLgGgRQgGgQAAgVQAAgTAGgRQAGgRAMgLQALgMARgGQAQgHATAAQAUAAAQAHQARAGALAMQAMALAGARQAGARAAATQAAAVgGAQQgGARgMALQgLAMgRAGQgQAHgUAAQgTAAgQgHgAgTgxQgIAFgFAIQgEAHgCAKQgCAKAAAJQAAAKACAKQACAKAEAIQAFAHAIAFQAIAFALAAQAMAAAIgFQAIgFAFgHQAEgIACgKQACgKAAgKQAAgJgCgKQgCgKgEgHQgFgIgIgFQgIgFgMAAQgLAAgIAFg");
	this.shape_33.setTransform(203.725,45.375);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgvBXQgKgDgIgHQgIgGgFgJQgEgKAAgNQAAgPAFgJQAFgKAIgFQAIgFALgDIAVgEIAUgDIASgDQAHgCAFgDQAFgEgBgIQAAgHgCgFQgDgEgEgCQgEgDgFgBIgMgBQgNAAgIAGQgIAGgBAOIgvAAQABgQAHgLQAIgLALgHQALgGAOgDQAOgDANAAQANAAANACQAOACAKAFQALAFAHAKQAHAJAAAQIAABXQAAAMACAKQABALADAFIgvAAIgCgIIgCgIQgLALgPAFQgOAFgQAAQgMAAgLgDgAAXAGIgKACIgKACIgLACIgKACQgFACgEADQgEADgCAEQgCAEAAAHQAAAGACAEQACAFAEACQAEADAFABIALABQANAAAIgFQAHgFAEgGQAEgHABgGIAAgLIAAgRQgDACgEACg");
	this.shape_34.setTransform(104.375,45.375);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AggBTQgQgGgLgMQgMgLgGgQQgGgQAAgUQAAgSAGgRQAFgRAMgNQALgMAQgHQAQgHAUAAQAPAAAOAEQAOAEALAIQALAIAHAMQAHAMABARIguAAQgEgegeAAQgLAAgHAGQgIAFgFAIQgEAIgCAJQgCAKAAAJQAAAJACAKQACAJAEAIQAFAIAHAFQAIAFAKAAQAQAAAJgKQAKgJACgQIAtAAQgEAigWASQgWASgiAAQgSAAgQgHg");
	this.shape_35.setTransform(86.125,45.375);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AghBTQgRgGgLgMQgLgMgGgRQgGgQAAgUQAAgSAGgQQAGgRAMgMQALgMAQgHQAQgHATAAQAWAAAQAIQAQAJAKAOQALAOAEASQAFASgBATIh6AAQABAXAKAKQALALATAAQAOAAAKgHQAKgIACgHIAqAAQgKAegVANQgUAOgdAAQgTAAgQgHgAAmgRQgDgSgJgJQgIgKgRAAQgLAAgHAEQgHAEgFAGQgEAFgCAGQgCAHAAAFIBLAAIAAAAg");
	this.shape_36.setTransform(58.6173,45.375);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgWB2IAAjrIAtAAIAADrg");
	this.shape_37.setTransform(241.1,42.125);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AAhB2IAAhhQAAgVgGgJQgHgLgRAAQgSAAgIAMQgJAKAAAaIAABaIgvAAIAAjrIAvAAIAABZIAAAAQAKgPAOgHQANgGANAAQASAAAMAFQANAFAGAJQAIAJACANQADANAAAPIAABpg");
	this.shape_38.setTransform(209,42.125);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AAhBYIAAhgQAAgVgHgKQgGgLgRAAQgSAAgJAMQgJALAAAaIAABZIguAAIAAiqIAsAAIAAAYIABAAQAJgPAPgHQANgHAOAAQAUABAMAEQALAFAIAKQAGAIADAOQADANAAAPIAABpg");
	this.shape_39.setTransform(181.05,45.15);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AAeBVIgehxIAAAAIgdBxIgwAAIg2ipIAxAAIAgByIAAAAIAdhyIAsAAIAdByIABAAIAfhyIAwAAIg1Cpg");
	this.shape_40.setTransform(93.825,45.375);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AgwBSQgLgEgIgKQgGgJgEgNQgCgNAAgPIAAhoIAvAAIAABfQAAAVAHALQAGAKAQAAQATAAAIgMQAJgLAAgaIAAhYIAvAAIAACpIgsAAIAAgYIgBAAQgJAPgPAHQgNAGgPAAQgSAAgNgFg");
	this.shape_41.setTransform(51.05,45.575);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AhiB2IAAjrIBuAAQARAAAOADQAOADAKAHQAKAHAFALQAGALAAARQAAARgIAMQgJAMgPAIQAVAGALAPQALAPAAAWQAAASgHANQgHANgMAJQgLAIgQAEQgOAEgQAAgAguBNIA3AAIAOgBQAHgBAFgEQAGgDADgGQADgGAAgJQAAgTgKgHQgKgIgRAAIg4AAgAgugVIA0AAQAOAAAJgHQAIgHAAgOQAAgJgCgFQgDgFgFgDQgFgDgHgBQgGgCgHAAIgwAAg");
	this.shape_42.setTransform(30.525,42.125);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgZAZIAAgxIAzAAIAAAxg");
	this.shape_43.setTransform(166.925,122.05);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AghBTQgRgGgLgMQgLgMgGgRQgGgQAAgUQAAgSAGgQQAGgRAMgMQALgMAQgHQAQgHATAAQAWAAAQAIQAQAJAKAOQALAOAEASQAFASgBATIh6AAQABAXAKAKQALALATAAQAOAAAKgHQAKgIACgHIAqAAQgKAegVANQgUAOgdAAQgTAAgQgHgAAmgRQgDgSgJgJQgIgKgRAAQgLAAgHAEQgHAEgFAGQgEAFgCAGQgCAHAAAFIBLAAIAAAAg");
	this.shape_44.setTransform(153.2673,116.075);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgrBwQgOgHgKgMQgJgOgFgQQgFgQAAgSQAAgSAFgPQAFgPAJgNQAKgMAOgHQAOgHATgBQAOABAOAGQANAGAIANIABAAIAAhWIAvAAIAADqIgtAAIAAgVIAAAAQgJAOgNAFQgNAHgQAAQgTAAgPgIgAgRgTQgIAFgFAIQgEAGgDAKQgCAKAAAKQAAAKADAKQACAKAFAHQAFAJAIAEQAIAFAKAAQALAAAIgFQAHgEAFgIQAFgIACgKQACgKAAgKQAAgLgCgJQgCgKgFgHQgFgHgHgFQgIgEgLAAQgLAAgIAEg");
	this.shape_45.setTransform(133.775,113.05);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgjBTQgRgGgLgMQgMgLgGgRQgGgQAAgVQAAgTAGgRQAGgRAMgLQALgMARgGQAQgHATAAQAUAAAQAHQARAGALAMQAMALAGARQAGARAAATQAAAVgGAQQgGARgMALQgLAMgRAGQgQAHgUAAQgTAAgQgHgAgTgxQgIAFgFAIQgEAHgCAKQgCAKAAAJQAAAKACAKQACAKAEAIQAFAHAIAFQAIAFALAAQAMAAAIgFQAIgFAFgHQAEgIACgKQACgKAAgKQAAgJgCgKQgCgKgEgHQgFgIgIgFQgIgFgMAAQgLAAgIAFg");
	this.shape_46.setTransform(114.375,116.075);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AggBTQgQgGgLgMQgMgLgGgQQgGgQAAgUQAAgSAGgRQAFgRAMgNQALgMAQgHQAQgHAUAAQAPAAAOAEQAOAEALAIQALAIAHAMQAHAMABARIguAAQgEgegeAAQgLAAgHAGQgIAFgFAIQgEAIgCAJQgCAKAAAJQAAAJACAKQACAJAEAIQAFAIAHAFQAIAFAKAAQAQAAAJgKQAKgJACgQIAtAAQgEAigWASQgWASgiAAQgSAAgQgHg");
	this.shape_47.setTransform(95.425,116.075);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AghBTQgRgGgLgMQgLgMgGgRQgGgQAAgUQAAgSAGgQQAGgRAMgMQALgMAQgHQAQgHATAAQAWAAAQAIQAQAJAKAOQALAOAEASQAFASgBATIh6AAQABAXAKAKQALALATAAQAOAAAKgHQAKgIACgHIAqAAQgKAegVANQgUAOgdAAQgTAAgQgHgAAmgRQgDgSgJgJQgIgKgRAAQgLAAgHAEQgHAEgFAGQgEAFgCAGQgCAHAAAFIBLAAIAAAAg");
	this.shape_48.setTransform(76.6673,116.075);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("ABUBXIAAhfIgBgQQgBgIgDgGQgDgFgGgEQgFgDgKAAQgKAAgGAEQgHAEgDAGQgEAGgBAIIgBAQIAABdIgtAAIAAheIgBgPQAAgHgCgHQgDgGgGgEQgFgEgMAAIgIABQgGACgFAFQgFAEgEAHQgDAIgBAMIAABiIgvAAIAAipIAtAAIAAAXIAAAAQAJgNANgHQAOgIARAAQAQAAANAHQANAGAGAPQAIgLANgIQANgIASgBQANAAAMADQALAEAJAHQAIAIAEALQAGAMgBARIAABwg");
	this.shape_49.setTransform(52.65,115.85);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgXB2IAAiqIAuAAIAACqgAgXhOIAAgnIAuAAIAAAng");
	this.shape_50.setTransform(33.85,112.825);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AAbBvQgLABgJgCQgJgBgIgFQgHgEgEgIQgEgIAAgMIAAhkIgdAAIAAggIAdAAIAAgzIAtAAIAAAzIAjAAIAAAgIgjAAIAABTQAAAMAEAEQAEAEAMAAIAIgBIAHAAIAAAkIgNABIgPAAg");
	this.shape_51.setTransform(24.075,113.6);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("Ag4BzIgOgCIAAgmIANABIAOAAQAJgBAFgGQAEgGAAgIQAAgFgCgFIg7ifIAxAAIAmBzIABAAIAlhzIAwAAIhHC+QgHAVgNAJQgNAJgZAAIgOAAg");
	this.shape_52.setTransform(216.625,83.725);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AgRByQgPgGgIgPIAAAAIAAAXIgtAAIAAjrIAvAAIAABWIABAAQAIgOAPgFQAOgHAPAAQANAAANAGQANAFAKALQAKAKAGASQAGAPAAAYQAAAXgGASQgGAQgKAMQgKAKgNAGQgNAFgNAAQgSAAgOgGgAgRgTQgIAEgFAIQgFAHgCAKQgCAJgBALQABALACAKQACAKAFAHQAFAIAIAFQAHAEAKAAQAKAAAIgEQAHgFAFgIQAEgHADgKQADgKgBgLQABgLgDgJQgDgKgEgHQgFgIgHgEQgIgEgKgBQgKABgHAEg");
	this.shape_53.setTransform(198.65,77.7);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AAbBvQgLAAgJgBQgJgBgIgEQgHgFgEgIQgEgIAAgMIAAhkIgdAAIAAggIAdAAIAAgyIAtAAIAAAyIAjAAIAAAgIgjAAIAABTQAAAMAEAEQAEAEAMAAIAIgBIAHgBIAAAlIgNABIgPAAg");
	this.shape_54.setTransform(174.025,78.25);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgWB2IAAiqIAuAAIAACqgAgWhOIAAgnIAuAAIAAAng");
	this.shape_55.setTransform(164.5,77.475);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AghBTQgRgGgLgMQgLgMgGgRQgGgQAAgUQAAgSAGgQQAGgRAMgMQALgMAQgHQAQgHATAAQAWAAAQAIQAQAJAKAOQALAOAEASQAFASgBATIh6AAQABAXAKAKQALALATAAQAOAAAKgHQAKgIACgHIAqAAQgKAegVANQgUAOgdAAQgTAAgQgHgAAmgRQgDgSgJgJQgIgKgRAAQgLAAgHAEQgHAEgFAGQgEAFgCAGQgCAHAAAFIBLAAIAAAAg");
	this.shape_56.setTransform(142.4173,80.725);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AhNBVIAAgjIBXhjIhRAAIAAgjICPAAIAAAjIhYBjIBeAAIAAAjg");
	this.shape_57.setTransform(124.775,80.725);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgXB2IAAiqIAuAAIAACqgAgXhOIAAgnIAuAAIAAAng");
	this.shape_58.setTransform(112.35,77.475);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AAhBYIAAhgQAAgVgHgLQgGgKgRAAQgSAAgJAMQgJALAAAaIAABZIguAAIAAiqIAsAAIAAAXIABAAQAJgOAPgHQANgGAOgBQAUAAAMAGQALAFAIAIQAGAJADAOQADANAAAPIAABpg");
	this.shape_59.setTransform(98.7,80.5);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AgvBXQgKgDgIgHQgIgGgFgJQgEgKAAgNQAAgPAFgJQAFgKAIgFQAIgFALgDIAVgEIAUgDIASgDQAHgCAFgDQAFgEgBgIQAAgHgCgFQgDgEgEgCQgEgDgFgBIgMgBQgNAAgIAGQgIAGgBAOIgvAAQABgQAHgLQAIgLALgHQALgGAOgDQAOgDANAAQANAAANACQAOACAKAFQALAFAHAKQAHAJAAAQIAABXQAAAMACAKQABALADAFIgvAAIgCgIIgCgIQgLALgPAFQgOAFgQAAQgMAAgLgDgAAXAGIgKACIgKACIgLACIgKACQgFACgEADQgEADgCAEQgCAEAAAHQAAAGACAEQACAFAEACQAEADAFABIALABQANAAAIgFQAHgFAEgGQAEgHABgGIAAgLIAAgRQgDACgEACg");
	this.shape_60.setTransform(79.725,80.725);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgcB1QgNgEgLgGQgLgHgHgKQgHgLgBgOIAuAAQAEANAJAFQAKAFALAAQAUAAAJgMQAJgMAAgSIAAgWIgBAAQgHANgOAHQgOAGgPAAQgTAAgOgHQgOgGgJgMQgIgMgEgOQgFgQAAgRQAAgRAFgPQAFgQAJgLQAJgMAOgHQAOgHASAAQAPAAANAGQANAHAIAOIABAAIAAgWIAtAAIAACeQAAALgDANQgDANgJALQgKAMgRAIQgRAIgdAAQgMAAgNgDgAgQhQQgHAEgFAHQgEAHgDAJQgCAIAAAKQAAAJACAJQACAJAEAIQAFAGAHAEQAHAFAKAAQAKAAAIgEQAHgEAFgHQAFgFADgJQACgIAAgJQAAgLgCgJQgCgKgFgHQgEgHgIgEQgHgFgMAAQgJAAgHAEg");
	this.shape_61.setTransform(60.325,83.725);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("Ag2BYIAAiqIAtAAIAAAfIAAAAQADgHAGgHQAFgHAHgFQAHgFAIgCQAJgCAJgBIAKACIAAArIgIgBIgJAAQgNAAgJAEQgJAEgFAIQgEAHgDAKQgCAKAAAKIAABOg");
	this.shape_62.setTransform(45.425,80.5);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AgjBTQgRgGgLgMQgMgLgGgRQgGgQAAgVQAAgTAGgRQAGgRAMgLQALgMARgGQAQgHATAAQAUAAAQAHQARAGALAMQAMALAGARQAGARAAATQAAAVgGAQQgGARgMALQgLAMgRAGQgQAHgUAAQgTAAgQgHgAgTgxQgIAFgFAIQgEAHgCAKQgCAKAAAJQAAAKACAKQACAKAEAIQAFAHAIAFQAIAFALAAQAMAAAIgFQAIgFAFgHQAEgIACgKQACgKAAgKQAAgJgCgKQgCgKgEgHQgFgIgIgFQgIgFgMAAQgLAAgIAFg");
	this.shape_63.setTransform(28.475,80.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_14},{t:this.shape_13,p:{x:58.6173,y:45.375}},{t:this.shape_12,p:{x:86.125,y:45.375}},{t:this.shape_11,p:{x:104.375,y:45.375}},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8,p:{x:147.175}},{t:this.shape_7,p:{x:171.925}},{t:this.shape_6},{t:this.shape_5,p:{x:203.725,y:45.375}},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1,p:{x:277.7673,y:45.375}}]},13).to({state:[{t:this.shape_14},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8,p:{x:147.175}},{t:this.shape_7,p:{x:171.925}},{t:this.shape_6},{t:this.shape_33},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_5,p:{x:219.875,y:80.725}},{t:this.shape_19},{t:this.shape_13,p:{x:38.4673,y:116.075}},{t:this.shape_1,p:{x:57.0173,y:116.075}},{t:this.shape_18},{t:this.shape_17},{t:this.shape_11,p:{x:114.975,y:116.075}},{t:this.shape_12,p:{x:133.825,y:116.075}},{t:this.shape_16},{t:this.shape_15}]},21).to({state:[]},115).to({state:[{t:this.shape_42},{t:this.shape_41},{t:this.shape_8,p:{x:66.125}},{t:this.shape_40},{t:this.shape_13,p:{x:116.3173,y:45.375}},{t:this.shape_12,p:{x:143.825,y:45.375}},{t:this.shape_11,p:{x:162.075,y:45.375}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_1,p:{x:227.7673,y:45.375}},{t:this.shape_37},{t:this.shape_7,p:{x:255.425}}]},8).to({state:[{t:this.shape_42},{t:this.shape_41},{t:this.shape_8,p:{x:66.125}},{t:this.shape_40},{t:this.shape_13,p:{x:116.3173,y:45.375}},{t:this.shape_12,p:{x:143.825,y:45.375}},{t:this.shape_11,p:{x:162.075,y:45.375}},{t:this.shape_39},{t:this.shape_38},{t:this.shape_1,p:{x:227.7673,y:45.375}},{t:this.shape_37},{t:this.shape_7,p:{x:255.425}},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43}]},21).to({state:[]},134).wait(138));

	// Warstwa_9
	this.clicktagbtn = new lib.Symbol2();
	this.clicktagbtn.name = "clicktagbtn";
	this.clicktagbtn.parent = this;
	this.clicktagbtn.setTransform(216.5,219.65,1,1,0,0,0,-63,-16.8);
	new cjs.ButtonHelper(this.clicktagbtn, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get(this.clicktagbtn).wait(450));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(136,113.1,174.5,156.4);
// library properties:
lib.properties = {
	id: '9A57CFF2877EAC48B113F7EA220390EE',
	width: 300,
	height: 250,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['9A57CFF2877EAC48B113F7EA220390EE'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;