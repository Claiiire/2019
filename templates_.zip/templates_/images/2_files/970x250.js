(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Warstwa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgcBGQgOgEgJgLQgKgKgFgOQgFgOAAgRQAAgPAFgOQAFgOAKgKQAKgLAOgFQANgGAQAAQASAAAOAHQAOAHAIAMQAJAMAEAQQAEAPgBAPIhnAAQAAAUAJAJQAJAJAQgBQAMAAAJgFQAJgHABgGIAjAAQgIAagRALQgSALgYAAQgQAAgOgGgAAggOQgCgQgIgIQgHgHgOAAQgJAAgGADQgGAEgEAEIgGAKIgBAKIA/AAIAAAAg");
	this.shape.setTransform(66.885,-26.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AguBKIAAiQIAmAAIAAAbIABAAQACgGAFgGQAEgGAGgEQAGgEAHgCQAHgCAIAAIAJABIAAAlIgHgBIgIAAQgLAAgHADQgIAEgEAGQgEAGgCAJQgCAIAAAJIAABBg");
	this.shape_1.setTransform(54.425,-26.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgoBGQgLgEgFgIQgGgHgDgMQgCgLAAgNIAAhYIAoAAIAABRQAAASAFAJQAGAIAOAAQAQAAAHgJQAHgKAAgWIAAhLIAoAAIAACQIgmAAIAAgUIgBAAQgHAMgMAGQgMAFgMAAQgQAAgKgEg");
	this.shape_2.setTransform(40.25,-26.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAGBdQgHgBgHgEQgGgDgDgHQgFgHAAgLIAAhUIgXAAIAAgbIAXAAIAAgrIAoAAIAAArIAdAAIAAAbIgdAAIAABHQgBAKAEADQADAEALAAIAFgBIAHgBIAAAfIgLABIgNABQgJAAgIgCg");
	this.shape_3.setTransform(27.2,-28.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgoBJQgIgCgIgFQgGgFgEgJQgDgIAAgLQAAgMAEgIQAEgIAHgFQAHgEAIgCIASgEIASgCIAPgCQAGgDAEgDQAEgDAAgGQAAgGgDgEQgCgEgDgCIgIgDIgKAAQgLAAgGAEQgHAGgBALIgoAAQAAgOAHgJQAGgKAKgFQAJgFAMgDQAMgCALAAIAWABQAMACAJAFQAJAEAFAIQAHAIgBANIAABKIABATQABAJAEAEIgpAAIgBgGIgBgHQgKAKgNADQgMAEgOAAQgJAAgKgDgAAUAFIgIACIgKABIgIACIgJADQgFAAgDADQgDADgCADQgCADAAAHQAAAEACAEQACAEADACIAJADIAIABQALAAAHgEQAGgEADgGQADgFABgGIABgJIAAgPQgDADgDABg");
	this.shape_4.setTransform(14.6,-26.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgcBGQgOgEgJgLQgKgKgFgOQgFgOAAgRQAAgPAFgOQAFgOAKgKQAKgLAOgFQANgGAQAAQASAAAOAHQAOAHAIAMQAJAMAEAQQAEAPgBAPIhnAAQAAAUAJAJQAJAJAQgBQAMAAAJgFQAJgHABgGIAjAAQgIAagRALQgSALgYAAQgQAAgOgGgAAggOQgCgQgIgIQgHgHgOAAQgJAAgGADQgGAEgEAEIgGAKIgBAKIA/AAIAAAAg");
	this.shape_5.setTransform(-1.065,-26.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AhFBkIAAjHICLAAIAAAlIhfAAIAAAuIBSAAIAAAiIhSAAIAABSg");
	this.shape_6.setTransform(-16.425,-29.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgeBHQgNgGgKgKQgKgJgGgOQgFgOAAgSQAAgQAFgOQAGgPAKgJQAKgKANgGQAOgFAQAAQARAAAOAFQANAGALAKQAJAJAGAPQAFAOAAAQQAAASgFAOQgGAOgJAJQgLAKgNAGQgOAFgRAAQgQAAgOgFgAgQgpQgGAEgEAHQgFAGgCAIQgBAJAAAHIABARQACAJAFAGQAEAHAGADQAHAEAJAAQAKAAAHgEQAHgDAEgHQADgGADgJIABgRQAAgHgBgJQgDgIgDgGQgEgHgHgEQgHgEgKAAQgJAAgHAEg");
	this.shape_7.setTransform(-41.1,-26.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgcBGQgOgEgJgLQgKgKgFgOQgFgOAAgRQAAgPAFgOQAFgOAKgKQAKgLAOgFQANgGAQAAQASAAAOAHQAOAHAIAMQAJAMAEAQQAEAPgBAPIhnAAQAAAUAJAJQAJAJAQgBQAMAAAJgFQAJgHABgGIAjAAQgIAagRALQgSALgYAAQgQAAgOgGgAAggOQgCgQgIgIQgHgHgOAAQgJAAgGADQgGAEgEAEIgGAKIgBAKIA/AAIAAAAg");
	this.shape_8.setTransform(-57.365,-26.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("ABGBKIAAhRIAAgNQAAgHgDgFQgDgEgFgDQgFgDgHAAQgJAAgGADQgEADgEAGQgDAFAAAGIgBAOIAABPIgnAAIAAhQIgBgNQAAgGgCgFQgCgGgFgDQgFgDgJAAIgHABQgFABgEAEQgFAEgDAGQgDAHAAAKIAABTIgoAAIAAiQIAlAAIAAAUIACAAQAHgLALgGQALgGAOAAQAOAAALAFQALAFAGAOQAGgKALgHQAMgHAOAAQAMAAAKACQAKADAGAGQAIAHADAKQAFAJAAAOIAABgg");
	this.shape_9.setTransform(-77.75,-26.475);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgTBkIAAiQIAnAAIAACQgAgThCIAAghIAnAAIAAAhg");
	this.shape_10.setTransform(-93.725,-29.05);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgYBkIhBjHIAtAAIAsCLIAAAAIAtiLIAtAAIhCDHg");
	this.shape_11.setTransform(-105.875,-29.05);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AA0BkIgPgsIhKAAIgQAsIgrAAIBLjHIAsAAIBKDHgAAZAXIgZhJIAAAAIgaBJIAzAAg");
	this.shape_12.setTransform(-131.5,-29.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol8, new cjs.Rectangle(-143.1,-48.3,219.89999999999998,37.4), null);


(lib.Symbol7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Warstwa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgmAmIAAhLIBNAAIAABLg");
	this.shape.setTransform(307.575,-36.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhUCrIgWgCIAAg5IAVACQAKABAKgBQAOgBAHgKQAHgJAAgLQAAgJgEgHIhZjuIBLAAIA4CtIABAAIA4itIBJAAIhrEdQgLAfgTAOQgVANgkAAIgVgBg");
	this.shape_1.setTransform(288.375,-41.275);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgxB8QgYgKgQgRQgRgQgKgZQgJgYAAgcQAAgcAJgaQAIgaARgSQARgSAYgLQAYgKAeAAQAXAAAVAGQAVAGAQAMQARALAKATQAKASACAYIhEAAQgHgrgtgBQgQAAgLAIQgMAIgHAMQgHAMgDAOQgDAPAAANQAAAOADAOQADAOAHAMQAGAMAMAHQALAIAPAAQAZAAAOgOQAOgOADgYIBEAAQgHAzghAaQggAbgzAAQgcAAgYgKg");
	this.shape_2.setTransform(262.125,-45.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhHCCQgQgFgLgKQgMgJgHgOQgGgOAAgUQAAgVAHgOQAIgPAMgIQAMgHAQgFQAPgEAQgDIAfgDQAOgCAMgDQAMgDAHgGQAHgFgBgLQAAgMgEgGQgDgHgGgDQgHgEgIgBIgRgCQgUABgMAIQgMAKgCAUIhGAAQACgZALgQQALgQAQgKQARgKAVgEQAVgEAUAAQATAAAUADQAUACAQAIQAQAIALAOQAKAOAAAXIAACDQAAASACAQQACAQAFAHIhHAAIgDgMIgCgMQgRARgWAHQgWAHgYAAQgSAAgQgEgAAiAJIgOAEIgQACIgQACIgQAFQgHACgGAEQgGAEgDAGQgEAHAAAKQAAAJAEAGQADAHAGAEQAGADAIACQAIABAJABQATAAAMgIQALgGAFgKQAGgJABgLIABgPIAAgaQgEADgHADg");
	this.shape_3.setTransform(233.775,-45.75);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AglB/IhYj+IBKAAIA0CtIABAAIA2itIBGAAIhXD+g");
	this.shape_4.setTransform(207.325,-45.75);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgiCwIAAj+IBFAAIAAD+gAgih1IAAg6IBFAAIAAA6g");
	this.shape_5.setTransform(188.6,-50.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AhRCDIAAj+IBCAAIAAAvIACAAQAEgMAJgKQAHgKALgHQALgHAMgEQAMgEAOAAQAHAAAIACIAABBIgMgBIgNgBQgTAAgNAHQgOAGgIALQgHALgEAPQgDAPAAAQIAABzg");
	this.shape_6.setTransform(174.3,-46.075);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AiLCwIAAlfICeAAQAhAAAXAKQAXAKAOAPQAPAQAHAUQAGAVAAAVQAAAVgGAVQgHAUgPAPQgOAQgXAJQgXAKghAAIhRAAIAAB+gAg+gKIA8AAQANABAMgCQAMgCAKgGQAJgFAGgLQAGgKAAgRQAAgRgGgKQgGgLgJgFQgKgGgMgCQgMgCgNAAIg8AAg");
	this.shape_7.setTransform(148.375,-50.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol7, new cjs.Rectangle(129,-83,187.3,62.7), null);


(lib.Symbol6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Warstwa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhBCoQgVgLgOgTQgOgTgIgYQgGgZgBgbQABgaAGgWQAIgYAOgSQAOgTAVgLQAVgLAdAAQAVAAAVAKQAUAJALATIABAAIAAiAIBGAAIAAFfIhCAAIAAghIgBAAQgNAVgUAJQgTAJgZAAQgcAAgWgLgAgagcQgMAHgHALQgHAKgEAPQgDAOAAAQQABAPADAPQAEAOAHAMQAHAMAMAHQALAHAQAAQARAAALgHQAMgHAHgLQAHgMADgPQADgPAAgPQAAgQgDgPQgDgOgHgKQgHgLgMgHQgLgHgRAAQgRAAgLAHg");
	this.shape.setTransform(-25,-12.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgyB8QgYgKgRgRQgRgSgJgZQgJgYAAgeQAAgbAJgZQAKgZARgRQARgTAYgKQAYgKAcAAQAhAAAYANQAYAMAPAVQAQAVAHAbQAHAcgCAcIi3AAQABAiAQAQQAQAPAdAAQAVAAAPgLQAPgLAEgLIA9AAQgOAugfATQgeAUgsAAQgdAAgYgKgAA5gbQgFgagNgNQgMgPgaAAQgQABgLAFQgLAGgGAJQgHAHgDAKQgDAKAAAGIBxAAIAAAAg");
	this.shape_1.setTransform(-53.3278,-7.75);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgxB8QgYgKgQgRQgRgQgKgZQgJgYAAgcQAAgdAJgZQAIgZARgTQARgSAYgLQAYgKAeAAQAXAAAVAGQAVAFAQAMQARANAKASQAKASACAYIhEAAQgHgsgtAAQgQABgLAHQgMAIgHAMQgHAMgDAOQgDAPAAAOQAAANADAPQADAOAHAMQAGALAMAIQALAHAPAAQAZAAAOgOQAOgPADgXIBEAAQgHAzghAaQggAbgzAAQgcAAgYgKg");
	this.shape_2.setTransform(-80.875,-7.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAxCDIAAiPQAAgggJgPQgKgQgaAAQgbAAgNARQgNARAAAnIAACFIhGAAIAAj+IBDAAIAAAjIABAAQAOgWAVgKQAUgKAWAAQAdAAARAIQASAHALAOQAKANAEAUQAFATAAAYIAACcg");
	this.shape_3.setTransform(-109.525,-8.075);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AhHCCQgQgFgLgKQgMgIgHgPQgGgOAAgUQAAgVAHgOQAIgPAMgIQAMgHAQgFQAPgEAQgDIAfgDQAOgCAMgDQAMgCAHgHQAHgFgBgLQAAgMgEgGQgDgGgGgEQgHgEgIgBIgRgBQgUAAgMAJQgMAIgCAVIhGAAQACgYALgRQALgQAQgKQARgKAVgEQAVgEAUAAQATAAAUADQAUACAQAIQAQAIALAOQAKAOAAAYIAACCQAAASACAQQACAQAFAIIhHAAIgDgNIgCgMQgRARgWAHQgWAHgYAAQgSAAgQgEgAAiAJIgOAEIgQACIgQACIgQAFQgHACgGAEQgGAEgDAHQgEAGAAAKQAAAKAEAFQADAHAGAEQAGADAIACQAIACAJgBQATABAMgIQALgGAFgKQAGgKABgKIABgPIAAgaQgEADgHADg");
	this.shape_4.setTransform(-138.025,-7.75);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AglCAIhYj/IBKAAIA0CuIABAAIA2iuIBGAAIhXD/g");
	this.shape_5.setTransform(-164.475,-7.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AhACoQgWgLgOgTQgPgTgGgYQgIgZABgbQgBgaAIgWQAGgYAPgSQAOgTAVgLQAVgLAcAAQAWAAAUAKQAVAJAMATIABAAIAAiAIBGAAIAAFfIhDAAIAAghIgBAAQgMAVgVAJQgTAJgZAAQgcAAgVgLgAgagcQgMAHgHALQgHAKgDAPQgDAOAAAQQAAAPADAPQAEAOAHAMQAHAMAMAHQAMAHAPAAQARAAAMgHQALgHAHgLQAHgMADgPQADgPAAgPQAAgQgDgPQgDgOgHgKQgHgLgLgHQgMgHgRAAQgQAAgMAHg");
	this.shape_6.setTransform(-192.45,-12.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("ABcCwIgbhOIiDAAIgbBOIhOAAICFlfIBOAAICEFfgAAtAoIgsiAIgBAAIgtCAIBaAAg");
	this.shape_7.setTransform(-223.45,-12.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol6, new cjs.Rectangle(-242.3,-45,234.70000000000002,62.7), null);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Warstwa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(-150,-125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-300,-250,300,250);


(lib.Symbol2 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Warstwa_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgQAqQgIgDgFgGQgFgGgDgIQgCgJgBgKQAAgJADgIQAEgJAFgGQAGgGAHgDQAIgEAIAAQALAAAIAFQAIAEAFAIQAEAIACAIQACAKgBAGIhAAAIABALIAFAJQADAEAGADQAFACAGAAQAJABAGgFQAGgEACgJIAOAAQgDAPgKAIQgJAHgPAAQgKAAgIgEgAAZgHQAAgGgCgEIgFgIQgEgDgEgCQgFgCgFAAQgFAAgEACQgFACgDADIgFAIQgCAEAAAGIAxAAIAAAAg");
	this.shape.setTransform(-117.845,-31.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AANA5IgKgBQgDgBgCgCQgDgBgCgFIgBgJIAAg3IgOAAIAAgNIAOAAIAAgaIAOAAIAAAaIASAAIAAANIgSAAIAAA1IABAFIABACIADABIAGAAIAHAAIAAANg");
	this.shape_1.setTransform(-124.95,-33.15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAWArQgDgDAAgIQgGAIgIADQgHADgJAAQgGAAgFgBIgKgFQgEgCgCgGQgCgEAAgHQAAgHACgFQADgEAEgDQAEgCAGgCIALgDIAKgBIAJgCQAEgBADgDQACgCAAgDQAAgFgCgDQgBgDgDgCIgGgCIgGAAQgKAAgGADQgGAEAAAKIgPAAQABgIADgHQADgFAFgEQAFgDAGgBIAOgCIALABQAGABAFACQAFADADAFQACAFAAAHIAAAsIABAIQAAABABAAQAAABAAAAQABAAABAAQAAAAABAAIAEgBIAAALQgDADgHAAQgGAAgDgDgAALACIgJABIgJABQgFABgEACQgEABgCAEQgDADAAAGQAAADACADIADADIAGACIAGABQAHAAAEgCQAFgBAEgDIAFgHIABgHIAAgOQgDACgEABg");
	this.shape_2.setTransform(-131.475,-31.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgGAsIghhXIAQAAIAXBJIABAAIAYhJIAPAAIggBXg");
	this.shape_3.setTransform(-140.05,-31.85);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgGA9IAAhXIANAAIAABXgAgGgqIAAgSIANAAIAAASg");
	this.shape_4.setTransform(-145.775,-33.525);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgWAtIAAhXIAOAAIAAATIAAAAQAFgLAHgFQAHgFAMAAIAAAPQgJABgFACQgHACgCAFQgFAFgBAGQgCAGABAIIAAAng");
	this.shape_5.setTransform(-149.55,-31.95);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgpA+IAAh5IAPAAIAAAMQADgHAIgDQAIgEAIAAQALAAAHAEQAIAEAEAGQAFAHADAIQACAIAAAKQAAAJgCAHQgDAJgFAGQgEAGgIAEQgHADgKAAIgHgBIgIgCIgHgEIgGgGIAAAtgAgMgtQgFADgEAFQgDAEgBAGIgBAMQAAAHABAGQABAFADAEQAEAFAFADQAGADAGAAQAIAAAEgDQAFgDADgFQADgFACgFIACgMQAAgHgCgFQgCgGgDgFQgEgEgFgDQgFgDgGAAQgHAAgFADg");
	this.shape_6.setTransform(-157.3,-30.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AANA5IgKgBQgDgBgCgCQgDgBgCgFIgBgJIAAg3IgOAAIAAgNIAOAAIAAgaIAOAAIAAAaIASAAIAAANIgSAAIAAA1IAAAFIACACIAEABIAFAAIAHAAIAAANg");
	this.shape_7.setTransform(-169.4,-33.15);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgGA9IAAhXIANAAIAABXgAgGgqIAAgSIANAAIAAASg");
	this.shape_8.setTransform(-173.375,-33.525);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgpA+IAAh5IAPAAIAAAMQAEgHAHgDQAIgEAIAAQAKAAAIAEQAHAEAGAGQAFAHACAIQADAIAAAKQAAAJgDAHQgCAJgFAGQgGAGgHAEQgIADgKAAIgGgBIgHgCIgIgEIgGgGIAAAtgAgMgtQgFADgDAFQgEAEgCAGIgBAMQABAHABAGQABAFAEAEQADAFAGADQAEADAHAAQAHAAAFgDQAGgDACgFQAEgFABgFIABgMQAAgHgBgFQgCgGgDgFQgDgEgGgDQgFgDgGAAQgHAAgFADg");
	this.shape_9.setTransform(-184,-30.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgQAqQgIgDgFgGQgFgGgDgIQgCgJgBgKQAAgJADgIQAEgJAFgGQAGgGAHgDQAIgEAIAAQALAAAIAFQAIAEAFAIQAEAIACAIQACAKgBAGIhAAAIABALIAFAJQADAEAGADQAFACAGAAQAJABAGgFQAGgEACgJIAOAAQgDAPgKAIQgJAHgPAAQgKAAgIgEgAAZgHQAAgGgCgEIgFgIQgEgDgEgCQgFgCgFAAQgFAAgEACQgFACgDADIgFAIQgCAEAAAGIAxAAIAAAAg");
	this.shape_10.setTransform(-193.395,-31.85);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgQAqQgIgDgFgGQgFgGgDgIQgCgJgBgKQAAgJADgIQAEgJAFgGQAGgGAHgDQAIgEAIAAQALAAAIAFQAIAEAFAIQAEAIACAIQACAKgBAGIhAAAIABALIAFAJQADAEAGADQAFACAGAAQAJABAGgFQAGgEACgJIAOAAQgDAPgKAIQgJAHgPAAQgKAAgIgEgAAZgHQAAgGgCgEIgFgIQgEgDgEgCQgFgCgFAAQgFAAgEACQgFACgDADIgFAIQgCAEAAAGIAxAAIAAAAg");
	this.shape_11.setTransform(-202.145,-31.85);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAeA9Igrg9IgUASIAAArIgQAAIAAh5IAQAAIAAA8IA8g8IAVAAIgyAxIA0BIg");
	this.shape_12.setTransform(-211.375,-33.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(3));

	// Warstwa_1
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("ArRDQQg9gBABg7IAAknQgBg7A9gBIWjAAQA9ABAAA7IAAEnQAAA7g9ABg");
	this.shape_13.setTransform(-165.75,-33.75);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(0,0,0,0.698)").s().p("ArRDQQg9gBABg7IAAknQgBg7A9gBIWjAAQA9ABAAA7IAAEnQAAA7g9ABg");
	this.shape_14.setTransform(-165.75,-33.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13}]}).to({state:[{t:this.shape_14}]},1).wait(2));

	// Warstwa_2
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#A6CDCE").s().p("EhZ2AV/QjdAAAAg8MAAAgqFQAAg8DdAAMCztAAAQDdAAAAA8MAAAAqFQAAA8jdAAg");
	this.shape_15.setTransform(303.675,-107.675);

	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-293.5,-248.4,1194.4,281.5);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Warstwa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("ADmAyIgGgJIgIAFQglAVgnAAQgdAAgMgTIgCgCIgBAAQgYAUgXAAQgXAAABgZQAAgLAEgQQAEgOAAgJQABgNgJAAQgJAAgNAWQgMAVgBAVQgBAQADAHQgYABgKgJQgJgHABgSQAAgMADgKQADgKABgJQAAgNgKAAQgJAAgKAUQgKASgCAWQAAAUADAHQgYABgLgLQgEgFgCgIIgEAEQgYAUgYAAQgLAAgGgHQgFgHAAgLQAAgLAHgYIAHgZQAAgJgGAAQgCAAgJAGQgHAUgXAcQggApgWAAQgOAAgKgZIgMgtQgHgZgIAAQgCAAgLAHIgHgJIAXgUQAPgOAIAAQATgCAEAaIAGAkQAGAXAGAAQAFAAAKgQQAKgOABgIQABgNgMAAQgGAAgGACQAMglAhABQAVAAACAZIAKgJQAQgOAHAAQAMgBAFAHQAGAIgCANQgFAWgFAfQAAAPALAAQAFAAANgLIAAAAIADgRQADgPAAgKQABgGgEAAQgCAAgKAHIgJgJIAXgUQAPgOAFAAQAJgBAGAIQAGAIAAALIgBAHQAFgIAHgGQARgOAUgCQARgBAIAJQAFAIgBAOIAGgEQAIgKAIgFQANgKAOgBQARgBAHAJQAHAIgBAOQAAAKgFASIgEAVQAAAHABADQACADAHAAQADAAAGgEIgBgJQABgbAZgaQAcgcAlAAQAjAAACAcQACASgWARQgWAVgjAFQAHAJAMAAQAaAAAegNIADgBIgBgEQgCgdAYgZQAagcAnAAQAYAAANAQQAMAPgBAYQgBAfgXAXQgXAYghAAQgdAAgOgSgAEQgRQgKAQgBAQQAAAJADAHQAEAHAHAAQAQAAAMgSQAJgQABgPQAAgKgDgIQgDgHgFAAQgTAAgLATgACTgSQgLAOgBANIAAAEQASgGANgMQAKgLAAgHQABgJgJAAQgKAAgLAOg");
	this.shape.setTransform(-35.3212,-6.7513);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AheAQQABghAnggQAnggAvAAQAbAAATAWQATAXgCAVQgBAgggAfQgkAigwAAQhLAAADhCg");
	this.shape_1.setTransform(-50.8,-17.4,0.2679,0.2635,0,0,0,-0.4,0.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70.6,-19.6,70.6,19.6);


// stage content:
(lib._970x250 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		if (!this.looped) this.looped = 1;
		
		
		this.clicktagbtn.addEventListener('click', gourl.bind(this));
		
		function gourl(){
			Enabler.exit("User exit");
		}
	}
	this.frame_449 = function() {
		if (this.looped++ > 1) 
		{
		this.stop();}
		else {this.gotoAndPlay(2);}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(449).call(this.frame_449).wait(451));

	// Warstwa_11
	this.instance = new lib.Symbol3();
	this.instance.parent = this;
	this.instance.setTransform(485,125,3.2333,1,0,0,0,-150,-125);
	new cjs.ButtonHelper(this.instance, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:0},7,cjs.Ease.get(1)).to({_off:true},1).wait(892));

	// Warstwa_10
	this.instance_1 = new lib.Symbol1("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(820.35,218,1.67,1.67,0,0,0,-70.6,0.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EhLxgThMCXjAAAMAAAAnDMiXjAAAg");
	this.shape.setTransform(485,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_1}]}).wait(900));

	// Warstwa_8
	this.instance_2 = new lib.Symbol6();
	this.instance_2.parent = this;
	this.instance_2.setTransform(125.65,38.3,1,1,0,0,0,-128.7,-25.6);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(320).to({_off:false},0).to({x:144.65,alpha:1},10,cjs.Ease.get(1)).wait(570));

	// Warstwa_7
	this.instance_3 = new lib.Symbol7();
	this.instance_3.parent = this;
	this.instance_3.setTransform(62.05,76.35,1,1,0,0,0,-65,-25.6);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(322).to({_off:false},0).to({x:81.05,alpha:1},10,cjs.Ease.get(1)).wait(568));

	// Warstwa_6
	this.instance_4 = new lib.Symbol8();
	this.instance_4.parent = this;
	this.instance_4.setTransform(75.6,114.4,1,1,0,0,0,-78.5,-14);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(343).to({_off:false},0).to({x:94.6,alpha:1},10,cjs.Ease.get(1)).wait(547));

	// Warstwa_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AglArQAHgBAHgFQAHgEAFgGQAEgHADgHQACgIAAgHIgkAAIAAhMIBNAAIAABMQAAAQgGAOQgGAOgLALQgKAKgNAGQgOAHgQADg");
	this.shape_1.setTransform(558.325,67.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAKCkQgNgCgMgGQgLgHgGgLQgGgMAAgUIAAiVIgrAAIAAgvIArAAIAAhMIBFAAIAABMIAzAAIAAAvIgzAAIAAB9QAAASAGAGQAFAGASAAIALAAIALgCIAAA2IgUACIgVABQgQAAgPgDg");
	this.shape_2.setTransform(542.975,50.325);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhHCCQgQgFgLgKQgMgIgHgPQgGgOAAgUQAAgVAHgOQAIgPAMgIQAMgIAQgEQAPgEAQgDIAfgDQAOgCAMgDQAMgCAHgHQAHgFgBgLQAAgLgEgHQgDgGgGgEQgHgEgIgBIgRgBQgUgBgMAKQgMAIgCAVIhGAAQACgZALgQQALgQAQgKQARgKAVgEQAVgEAUAAQATAAAUADQAUACAQAIQAQAIALAOQAKAOAAAYIAACCQAAASACAQQACAPAFAJIhHAAIgDgNIgCgMQgRARgWAHQgWAHgYAAQgSAAgQgEgAAiAJIgOAEIgQACIgQACIgQAFQgHACgGAEQgGAEgDAHQgEAGAAAKQAAAKAEAFQADAHAGAEQAGADAIACQAIACAJgBQATABAMgIQALgGAFgKQAGgKABgKIABgPIAAgaQgEAEgHACg");
	this.shape_3.setTransform(520.625,54);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgyB8QgYgJgRgSQgRgSgJgYQgJgZAAgdQAAgcAJgZQAKgZARgRQARgSAYgLQAYgKAcAAQAhAAAYAMQAYANAPAVQAQAVAHAbQAHAcgCAcIi3AAQABAiAQAQQAQAPAdAAQAVAAAPgLQAPgLAEgLIA9AAQgOAugfATQgeAUgsAAQgdAAgYgKgAA5gbQgFgagNgOQgMgOgaAAQgQABgLAFQgLAGgGAJQgHAHgDAKQgDAKAAAGIBxAAIAAAAg");
	this.shape_4.setTransform(492.8222,54);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AhRCDIAAj+IBCAAIAAAvIABAAQAGgMAIgKQAIgKAKgHQALgHAMgEQAMgEAOAAQAGAAAJACIAABBIgLgBIgOgBQgTAAgNAHQgOAGgIALQgHALgEAPQgDAPAAAQIAABzg");
	this.shape_5.setTransform(470.75,53.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgrCuQgTgEgRgLQgPgJgLgQQgLgQgBgVIBFAAQAFATAPAIQAOAIASAAQAdAAAOgSQANgSAAgbIAAgiIgBAAQgLAVgVAKQgVAJgWAAQgdAAgVgKQgUgKgOgSQgNgRgGgXQgGgXAAgaQAAgZAHgXQAHgWAOgSQANgRAVgLQAUgKAbAAQAYAAATAJQATAKANAWIABAAIAAgiIBCAAIAADuQAAAOgEAVQgEATgOARQgOARgaAMQgaAMgrAAQgSAAgUgFgAgYh4QgLAHgHAKQgHAJgDANQgDANAAAPQAAANACAOQADAOAHALQAGAKALAGQALAIAPAAQAPAAALgHQAMgGAHgJQAHgJAEgNQAEgMAAgOQAAgQgDgOQgDgOgHgLQgHgLgLgGQgMgHgRAAQgOABgKAFg");
	this.shape_6.setTransform(444.725,58.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgoCCQgWgFgQgKQgRgKgKgRQgLgRgBgaIBDAAQgBALAFAIQAFAJAHAFQAIAFAJACQAJADAKAAIAPgCQAJgCAGgDQAHgEAEgGQAFgGAAgKQAAgQgVgIQgVgHglgIIgdgIQgPgFgLgHQgMgHgGgMQgHgLAAgRQAAgZAJgQQAKgPAQgKQAQgJAUgEQATgDAUAAQAVAAATAEQATAEAQAJQAOAKALAPQAKAQACAXIhDAAQgBgUgNgHQgOgHgSAAIgNABQgGAAgHADQgFACgEAFQgEAFAAAHQAAAKAHAGQAHAGALADQALAEANADIAdAGQAPAEAPAFQAPAFALAIQALAHAHAMQAHAMAAASQAAAZgLARQgJARgQAKQgRALgVAEQgVAEgVAAQgWAAgUgEg");
	this.shape_7.setTransform(404.1,53.975);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgiCwIAAj+IBFAAIAAD+gAgih1IAAg6IBFAAIAAA6g");
	this.shape_8.setTransform(384.95,49.15);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("Ag2B8QgYgJgRgSQgRgQgKgZQgJgZAAgeQAAgeAJgZQAKgZARgRQARgSAYgJQAZgKAdAAQAeAAAYAKQAYAJASASQARARAJAZQAKAZAAAeQAAAegKAZQgJAZgRAQQgSASgYAJQgYAKgeAAQgdAAgZgKgAgdhJQgMAHgHALQgHALgDAPQgDAPAAAPQAAAPADAOQADAOAHANQAHALAMAHQAMAHARAAQARAAAMgHQAMgHAIgLQAHgNADgOQADgOAAgPQAAgPgDgPQgDgPgHgLQgIgLgMgHQgMgIgRAAQgRAAgMAIg");
	this.shape_9.setTransform(350.675,54);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgyB8QgYgJgRgSQgRgSgJgYQgJgZAAgdQAAgcAJgZQAKgZARgRQARgSAYgLQAYgKAcAAQAhAAAYAMQAYANAPAVQAQAVAHAbQAHAcgCAcIi3AAQABAiAQAQQAQAPAdAAQAVAAAPgLQAPgLAEgLIA9AAQgOAugfATQgeAUgsAAQgdAAgYgKgAA5gbQgFgagNgOQgMgOgaAAQgQABgLAFQgLAGgGAJQgHAHgDAKQgDAKAAAGIBxAAIAAAAg");
	this.shape_10.setTransform(321.8222,54);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AhACoQgWgLgOgTQgOgTgIgYQgGgZAAgbQAAgaAGgWQAIgYAOgSQAOgTAVgLQAVgLAcAAQAWAAAUAKQAVAJAMATIABAAIAAiAIBFAAIAAFfIhCAAIAAghIgBAAQgNAVgUAJQgTAJgZAAQgcAAgVgLgAgagcQgMAHgHALQgHAKgDAPQgDAOgBAQQAAAPAEAPQAEAOAHAMQAHAMAMAHQAMAHAPAAQARAAALgHQANgHAGgLQAHgMADgPQADgPAAgPQAAgQgDgPQgDgOgHgKQgHgLgMgHQgLgHgRAAQgRAAgLAHg");
	this.shape_11.setTransform(292.55,49.475);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgiCwIAAj+IBFAAIAAD+gAgih1IAAg6IBFAAIAAA6g");
	this.shape_12.setTransform(272.1,49.15);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AglCAIhYj/IBKAAIA0CuIABAAIA2iuIBGAAIhXD/g");
	this.shape_13.setTransform(253.325,54);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AhHCCQgQgFgLgKQgMgIgHgPQgGgOAAgUQAAgVAHgOQAIgPAMgIQAMgIAQgEQAPgEAQgDIAfgDQAOgCAMgDQAMgCAHgHQAHgFgBgLQAAgLgEgHQgDgGgGgEQgHgEgIgBIgRgBQgUgBgMAKQgMAIgCAVIhGAAQACgZALgQQALgQAQgKQARgKAVgEQAVgEAUAAQATAAAUADQAUACAQAIQAQAIALAOQAKAOAAAYIAACCQAAASACAQQACAPAFAJIhHAAIgDgNIgCgMQgRARgWAHQgWAHgYAAQgSAAgQgEgAAiAJIgOAEIgQACIgQACIgQAFQgHACgGAEQgGAEgDAHQgEAGAAAKQAAAKAEAFQADAHAGAEQAGADAIACQAIACAJgBQATABAMgIQALgGAFgKQAGgKABgKIABgPIAAgaQgEAEgHACg");
	this.shape_14.setTransform(213.325,54);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgyB8QgYgJgRgSQgRgSgJgYQgJgZAAgdQAAgcAJgZQAKgZARgRQARgSAYgLQAYgKAcAAQAhAAAYAMQAYANAPAVQAQAVAHAbQAHAcgCAcIi3AAQABAiAQAQQAQAPAdAAQAVAAAPgLQAPgLAEgLIA9AAQgOAugfATQgeAUgsAAQgdAAgYgKgAA5gbQgFgagNgOQgMgOgaAAQgQABgLAFQgLAGgGAJQgHAHgDAKQgDAKAAAGIBxAAIAAAAg");
	this.shape_15.setTransform(172.2222,54);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AhRCDIAAj+IBCAAIAAAvIABAAQAGgMAIgKQAIgKAKgHQALgHAMgEQANgEANAAQAGAAAJACIAABBIgLgBIgOgBQgTAAgNAHQgOAGgIALQgHALgDAPQgEAPAAAQIAABzg");
	this.shape_16.setTransform(150.15,53.675);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("Ag2B8QgYgJgRgSQgRgQgKgZQgJgZAAgeQAAgeAJgZQAKgZARgRQARgSAYgJQAZgKAdAAQAeAAAYAKQAYAJASASQARARAJAZQAKAZAAAeQAAAegKAZQgJAZgRAQQgSASgYAJQgYAKgeAAQgdAAgZgKgAgdhJQgMAHgHALQgHALgDAPQgDAPAAAPQAAAPADAOQADAOAHANQAHALAMAHQAMAHARAAQARAAAMgHQAMgHAIgLQAHgNADgOQADgOAAgPQAAgPgDgPQgDgPgHgLQgIgLgMgHQgMgIgRAAQgRAAgMAIg");
	this.shape_17.setTransform(124.675,54);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgnCwIAAjPIgqAAIAAgvIAqAAIAAgTQAAgjAVgWQAUgVAsAAIASABIASABIAAA0IgZgBQgPAAgGAHQgGAGAAAQIAAAPIAwAAIAAAvIgwAAIAADPg");
	this.shape_18.setTransform(101.8,49.15);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgyB8QgYgJgRgSQgRgSgJgYQgJgZAAgdQAAgcAJgZQAKgZARgRQARgSAYgLQAYgKAcAAQAhAAAYAMQAYANAPAVQAQAVAHAbQAHAcgCAcIi3AAQABAiAQAQQAQAPAdAAQAVAAAPgLQAPgLAEgLIA9AAQgOAugfATQgeAUgsAAQgdAAgYgKgAA5gbQgFgagNgOQgMgOgaAAQgQABgLAFQgLAGgGAJQgHAHgDAKQgDAKAAAGIBxAAIAAAAg");
	this.shape_19.setTransform(79.8222,54);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AiSCwIAAlfICkAAQAZAAAVAFQAUAEAPAKQAPAKAJARQAHARABAZQAAAagNASQgLASgYALQAgAJAQAXQAQAXAAAhQABAagLAUQgLAUgRAMQgSAMgWAGQgWAGgYAAgAhFB0IBSAAQALAAALgDQAKgCAIgFQAHgFAFgJQAFgIAAgPQAAgbgQgLQgPgLgZAAIhTAAgAhFggIBNAAQAVAAAOgKQANgKgBgXQAAgLgDgJQgGgIgHgEQgHgEgJgCQgKgCgLAAIhHAAg");
	this.shape_20.setTransform(49.55,49.15);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgmAmIAAhLIBNAAIAABLg");
	this.shape_21.setTransform(217.425,117.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgoCCQgWgFgRgKQgQgKgLgRQgKgRgBgaIBDAAQgBALAFAIQAFAJAHAFQAHAFAKACQAJADAKAAIAPgCQAIgCAIgDQAGgEAEgGQAFgGAAgKQAAgQgVgIQgVgHgkgIIgegIQgOgFgMgHQgLgHgHgMQgHgLAAgRQAAgZAKgQQAJgPAQgKQAQgJAUgEQATgDAUAAQAVAAATAEQATAEAPAJQAQAKAKAPQAKAQACAXIhDAAQgBgUgNgHQgOgHgSAAIgNABQgGAAgHADQgFACgEAFQgEAFAAAHQAAAKAHAGQAGAGAMADQALAEANADIAdAGQAPAEAPAFQAOAFAMAIQALAHAHAMQAHAMAAASQAAAZgLARQgJARgRAKQgQALgVAEQgVAEgWAAQgVAAgUgEg");
	this.shape_22.setTransform(197.8,108.725);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AApCwIhFhyIgbAaIAABYIhGAAIAAlfIBGAAIAAC8IBXhbIBTAAIhgBdIBrChg");
	this.shape_23.setTransform(172.55,103.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgxB9QgYgLgQgQQgRgSgKgYQgJgXAAgdQAAgcAJgaQAIgaARgSQARgTAYgKQAYgKAeAAQAXAAAVAGQAVAGAQAMQARALAKATQAKASACAZIhEAAQgHgtgtABQgQgBgLAJQgMAHgHAMQgHAMgDAPQgDAOAAAOQAAANADAOQADAOAHAMQAGAMAMAHQALAIAPAAQAZAAAOgOQAOgPADgXIBEAAQgHAzghAbQggAagzAAQgcAAgYgJg");
	this.shape_24.setTransform(143.225,108.75);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AhIB7QgRgHgLgOQgKgNgEgUQgFgTAAgYIAAicIBHAAIAACPQAAAgAJAPQAKAQAZAAQAcAAANgRQAMgRAAgnIAAiFIBHAAIAAD+IhDAAIAAgjIgCAAQgNAWgVAKQgUAKgWAAQgdAAgSgIg");
	this.shape_25.setTransform(114.575,109.075);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgpCCQgVgFgRgKQgQgKgLgRQgKgRgBgaIBCAAQABALAEAIQAFAJAHAFQAIAFAJACQAKADAJAAIAQgCQAHgCAHgDQAHgEAFgGQAEgGAAgKQAAgQgVgIQgVgHglgIIgdgIQgPgFgLgHQgMgHgGgMQgHgLAAgRQAAgZAJgQQAKgPAQgKQAQgJATgEQAUgDAVAAQATAAAUAEQATAEAPAJQAQAKAKAPQAKAQACAXIhCAAQgCgUgOgHQgOgHgRAAIgNABQgHAAgFADQgGACgEAFQgEAFAAAHQAAAKAHAGQAHAGALADQALAEANADIAdAGQAQAEAOAFQAPAFALAIQALAHAHAMQAHAMAAASQAAAZgKARQgLARgPAKQgRALgVAEQgVAEgWAAQgVAAgVgEg");
	this.shape_26.setTransform(87.15,108.725);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AAKCkQgNgCgMgGQgLgHgGgLQgGgMAAgUIAAiVIgrAAIAAgvIArAAIAAhMIBFAAIAABMIAzAAIAAAvIgzAAIAAB9QAAASAGAGQAFAGASAAIALAAIALgCIAAA2IgUACIgVABQgQAAgPgDg");
	this.shape_27.setTransform(542.975,50.325);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgiCwIAAj+IBFAAIAAD+gAgih1IAAg6IBFAAIAAA6g");
	this.shape_28.setTransform(272.1,49.15);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgpCCQgVgFgQgKQgRgKgKgRQgLgRgBgaIBCAAQABALAEAIQAFAJAHAFQAHAFAKACQAKADAJAAIAQgCQAHgCAHgDQAHgEAFgGQAEgGAAgKQAAgQgVgIQgVgHglgIIgdgIQgPgFgLgHQgMgHgGgMQgHgLAAgRQAAgZAJgQQAKgPAQgKQAQgJATgEQAUgDAVAAQATAAAUAEQATAEAQAJQAOAKALAPQAKAQACAXIhCAAQgCgUgNgHQgPgHgRAAIgNABQgHAAgFADQgGACgEAFQgEAFAAAHQAAAKAHAGQAGAGAMADQALAEANADIAdAGQAPAEAPAFQAPAFALAIQALAHAHAMQAHAMAAASQAAAZgKARQgLARgPAKQgRALgVAEQgVAEgVAAQgVAAgWgEg");
	this.shape_29.setTransform(517.25,53.975);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgxB8QgYgJgQgSQgRgQgKgZQgJgXAAgdQAAgdAJgZQAIgaARgSQARgSAYgLQAYgKAeAAQAXAAAVAGQAVAFAQAMQARANAKASQAKASACAYIhEAAQgHgsgtAAQgQABgLAHQgMAIgHAMQgHAMgDAOQgDAPAAAOQAAANADAPQADAOAHAMQAGALAMAIQALAHAPAAQAZAAAOgOQAOgPADgXIBEAAQgHAzghAaQggAbgzAAQgcAAgYgKg");
	this.shape_30.setTransform(444.825,54);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AAxCwIAAiQQAAgfgJgPQgKgQgZAAQgcABgNAQQgMAQAAAnIAACGIhHAAIAAlfIBHAAIAACFIABAAQANgXAVgKQAUgKATAAQAdABASAHQARAIALANQAKAOAEATQAFAUAAAXIAACcg");
	this.shape_31.setTransform(402.825,49.15);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AhIB7QgRgHgLgOQgKgNgEgUQgFgTAAgYIAAicIBHAAIAACPQAAAgAJAPQAKAQAZAAQAcAAANgRQAMgRAAgnIAAiFIBHAAIAAD+IhDAAIAAgjIgCAAQgNAWgVAKQgUAKgWAAQgdAAgSgIg");
	this.shape_32.setTransform(344.325,54.325);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AhRCDIAAj+IBDAAIAAAvIABAAQAEgMAJgKQAIgKAKgHQALgHAMgEQAMgEAOAAQAGAAAJACIAABBIgMgBIgNgBQgTAAgOAHQgNAGgIALQgHALgDAPQgEAPAAAQIAABzg");
	this.shape_33.setTransform(292.05,53.675);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AhRCDIAAj+IBCAAIAAAvIABAAQAGgMAIgKQAIgKAKgHQALgHAMgEQANgEANAAQAHAAAIACIAABBIgLgBIgOgBQgTAAgNAHQgOAGgIALQgHALgDAPQgEAPAAAQIAABzg");
	this.shape_34.setTransform(259.95,53.675);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AhIB7QgRgHgLgOQgKgNgEgUQgFgTAAgYIAAicIBHAAIAACPQAAAgAJAPQAKAQAZAAQAcAAANgRQAMgRAAgnIAAiFIBHAAIAAD+IhDAAIAAgjIgCAAQgNAWgVAKQgUAKgWAAQgdAAgSgIg");
	this.shape_35.setTransform(234.925,54.325);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AhUCrIgWgCIAAg5IAVACQAKABAKgBQAOgBAHgKQAHgJAAgLQAAgJgEgHIhZjuIBLAAIA4CtIABAAIA4itIBJAAIhrEdQgLAfgTAOQgVANgkAAIgVgBg");
	this.shape_36.setTransform(178.225,58.475);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AiBCvIAAlWIBDAAIAAAgIABAAQANgVAUgKQATgJAXAAQAeABAWAKQAVAMAPATQAOASAHAaQAHAYAAAbQAAAagHAXQgHAXgOASQgOATgVALQgVAKgcABQgXAAgUgKQgUgKgNgSIAAAAIAAB4gAgdhyQgMAGgHAMQgHALgDAPQgDAOAAAQQAAAQADAOQAEAOAHALQAHAMAMAGQALAIARgBQAQABAMgIQALgGAIgMQAHgLADgOQADgOAAgQQAAgPgDgOQgEgPgHgMQgIgMgLgGQgMgIgPAAQgSAAgLAIg");
	this.shape_37.setTransform(138.025,58.15);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("ABBCwIhpieIgsAtIAABxIhNAAIAAlfIBNAAIAACSICJiSIBgAAIiJCLICXDUg");
	this.shape_38.setTransform(51.05,49.15);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgmAmIAAhLIBNAAIAABLg");
	this.shape_39.setTransform(196.975,117.7);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgyB9QgYgLgRgRQgRgRgJgZQgJgZAAgdQAAgcAJgZQAKgYARgTQARgSAYgKQAYgKAcAAQAhAAAYAMQAYANAPAVQAQAVAHAbQAHAbgCAdIi3AAQABAiAQAPQAQAQAdAAQAVAAAPgLQAPgLAEgLIA9AAQgOAtgfAVQgeATgsAAQgdAAgYgJgAA5gaQgFgbgNgOQgMgOgaABQgQAAgLAFQgLAGgGAIQgHAJgDAJQgDAJAAAIIBxAAIAAAAg");
	this.shape_40.setTransform(176.3722,108.75);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AAKCkQgNgCgMgGQgLgHgGgLQgGgMAAgUIAAiVIgrAAIAAgvIArAAIAAhMIBFAAIAABMIAzAAIAAAvIgzAAIAAB9QAAASAGAGQAFAGASAAIALAAIALgCIAAA2IgUACIgVABQgQAAgPgDg");
	this.shape_41.setTransform(153.775,105.075);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AhHCBQgQgEgLgJQgMgJgHgPQgGgPAAgTQAAgWAHgOQAIgOAMgIQAMgHAQgFQAPgEAQgCIAfgFQAOgBAMgDQAMgDAHgFQAHgGgBgLQAAgLgEgHQgDgGgGgEQgHgEgIgCIgRgBQgUAAgMAJQgMAJgCAVIhGAAQACgYALgRQALgQAQgKQARgKAVgEQAVgEAUAAQATAAAUACQAUADAQAIQAQAIALAOQAKAOAAAXIAACEQAAARACAQQACAPAFAJIhHAAIgDgMIgCgNQgRARgWAHQgWAHgYAAQgSAAgQgFgAAiAJIgOADIgQADIgQADIgQADQgHADgGAEQgGAFgDAFQgEAHAAAKQAAAJAEAHQADAGAGAEQAGAEAIABQAIACAJAAQATgBAMgGQALgHAFgKQAGgJABgKIABgQIAAgaQgEADgHADg");
	this.shape_42.setTransform(131.425,108.75);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AglCAIhYj+IBKAAIA0CtIABAAIA2itIBGAAIhXD+g");
	this.shape_43.setTransform(104.975,108.75);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgiCwIAAj+IBFAAIAAD+gAgih1IAAg6IBFAAIAAA6g");
	this.shape_44.setTransform(86.25,103.9);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AhRCDIAAj+IBCAAIAAAvIABAAQAGgMAIgKQAIgKAKgHQALgHAMgEQANgEANAAQAGAAAJACIAABBIgLgBIgOgBQgTAAgNAHQgOAGgIALQgHALgEAPQgDAPAAAQIAABzg");
	this.shape_45.setTransform(71.95,108.425);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AiBCvIAAlXIBDAAIAAAhIABAAQANgVAUgKQATgIAXgBQAeAAAWAMQAVALAPASQAOATAHAaQAHAZAAAbQAAAZgHAWQgHAYgOATQgOASgVAKQgVAMgcgBQgXAAgUgJQgUgKgNgTIAAAAIAAB5gAgdhzQgMAIgHALQgHALgDAPQgDAPAAAPQAAAQADAPQAEANAHAMQAHAKAMAIQALAGARAAQAQAAAMgGQALgIAIgKQAHgMADgNQADgPAAgQQAAgPgDgPQgEgOgHgMQgIgLgLgIQgMgHgPAAQgSAAgLAHg");
	this.shape_46.setTransform(47.025,112.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17,p:{x:124.675}},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12,p:{x:272.1}},{t:this.shape_11},{t:this.shape_10,p:{x:321.8222}},{t:this.shape_9,p:{x:350.675}},{t:this.shape_8,p:{x:384.95,y:49.15}},{t:this.shape_7},{t:this.shape_6,p:{x:444.725}},{t:this.shape_5},{t:this.shape_4,p:{x:492.8222}},{t:this.shape_3},{t:this.shape_2,p:{x:542.975,y:50.325}},{t:this.shape_1}]},13).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17,p:{x:124.675}},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_28},{t:this.shape_11},{t:this.shape_10,p:{x:321.8222}},{t:this.shape_9,p:{x:350.675}},{t:this.shape_12,p:{x:384.95}},{t:this.shape_7},{t:this.shape_6,p:{x:444.725}},{t:this.shape_5},{t:this.shape_4,p:{x:492.8222}},{t:this.shape_3},{t:this.shape_27},{t:this.shape_1},{t:this.shape_8,p:{x:37.75,y:103.9}},{t:this.shape_2,p:{x:52.125,y:105.075}},{t:this.shape_26},{t:this.shape_25,p:{x:114.575,y:109.075}},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21}]},21).to({state:[]},115).to({state:[{t:this.shape_38},{t:this.shape_10,p:{x:80.7222}},{t:this.shape_4,p:{x:108.6222}},{t:this.shape_37},{t:this.shape_36},{t:this.shape_17,p:{x:205.675}},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_9,p:{x:315.075}},{t:this.shape_32},{t:this.shape_6,p:{x:373.025}},{t:this.shape_31},{t:this.shape_30},{t:this.shape_25,p:{x:472.875,y:54.325}},{t:this.shape_2,p:{x:495.525,y:50.325}},{t:this.shape_29}]},8).to({state:[{t:this.shape_38},{t:this.shape_10,p:{x:80.7222}},{t:this.shape_4,p:{x:108.6222}},{t:this.shape_37},{t:this.shape_36},{t:this.shape_17,p:{x:205.675}},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_9,p:{x:315.075}},{t:this.shape_32},{t:this.shape_6,p:{x:373.025}},{t:this.shape_31},{t:this.shape_30},{t:this.shape_25,p:{x:472.875,y:54.325}},{t:this.shape_2,p:{x:495.525,y:50.325}},{t:this.shape_29},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39}]},31).to({state:[]},124).wait(588));

	// Warstwa_9
	this.instance_5 = new lib.Symbol2();
	this.instance_5.parent = this;
	this.instance_5.setTransform(216.5,219.65,1,1,0,0,0,-63,-16.8);
	new cjs.ButtonHelper(this.instance_5, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(900));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(471,113.1,709.4000000000001,156.4);
// library properties:
lib.properties = {
	id: '9A57CFF2877EAC48B113F7EA220390EE',
	width: 970,
	height: 250,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['9A57CFF2877EAC48B113F7EA220390EE'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;