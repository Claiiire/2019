$(document).ready(function(){
	$('.open').click(function(){
		$('id01').toggleClass('box');
	});
});